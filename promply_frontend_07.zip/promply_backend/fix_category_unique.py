#!/usr/bin/env python3
"""
Script para corrigir constraint UNIQUE em category.name
Arquivo: prompt_manager/fix_category_unique.py

PROBLEMA:
- Constraint UNIQUE apenas em 'name' impede usuários diferentes de terem categorias com mesmo nome
  
SOLUÇÃO:
- Remover UNIQUE de 'name'
- Adicionar UNIQUE composto em (user_id, name)
"""

from src.main import app, db
from sqlalchemy import text

def fix_category_unique_constraint():
    with app.app_context():
        print("=" * 70)
        print("🔧 CORRIGINDO CONSTRAINT UNIQUE EM CATEGORIAS")
        print("=" * 70)
        
        try:
            # 1. Verificar estrutura atual
            print("\n📋 1. Verificando estrutura atual da tabela category...")
            result = db.session.execute(text("PRAGMA table_info(category)")).fetchall()
            print("\n   Colunas atuais:")
            for col in result:
                print(f"      {col}")
            
            # 2. Verificar constraints atuais
            print("\n📋 2. Verificando constraints atuais...")
            result = db.session.execute(text("SELECT sql FROM sqlite_master WHERE type='table' AND name='category'")).fetchone()
            print(f"\n   SQL atual:")
            print(f"   {result[0] if result else 'Não encontrado'}")
            
            # 3. Criar tabela temporária com estrutura correta
            print("\n🔨 3. Criando tabela temporária com constraint correto...")
            db.session.execute(text("""
                CREATE TABLE category_new (
                    user_id INTEGER,
                    id INTEGER NOT NULL PRIMARY KEY,
                    name VARCHAR(100) NOT NULL,
                    description TEXT,
                    color VARCHAR(7) DEFAULT '#3B82F6',
                    is_template BOOLEAN DEFAULT 0,
                    created_at DATETIME,
                    FOREIGN KEY(user_id) REFERENCES user (id),
                    UNIQUE (user_id, name)
                )
            """))
            print("   ✅ Tabela temporária criada")
            
            # 4. Copiar dados
            print("\n📦 4. Copiando dados da tabela antiga...")
            db.session.execute(text("""
                INSERT INTO category_new (user_id, id, name, description, color, is_template, created_at)
                SELECT user_id, id, name, description, color, is_template, created_at
                FROM category
            """))
            
            rows_copied = db.session.execute(text("SELECT COUNT(*) FROM category_new")).fetchone()[0]
            print(f"   ✅ {rows_copied} registros copiados")
            
            # 5. Dropar tabela antiga
            print("\n🗑️  5. Removendo tabela antiga...")
            db.session.execute(text("DROP TABLE category"))
            print("   ✅ Tabela antiga removida")
            
            # 6. Renomear tabela nova
            print("\n✏️  6. Renomeando tabela nova...")
            db.session.execute(text("ALTER TABLE category_new RENAME TO category"))
            print("   ✅ Tabela renomeada")
            
            # 7. Commit
            db.session.commit()
            print("\n💾 7. Commit realizado com sucesso!")
            
            # 8. Verificar nova estrutura
            print("\n📋 8. Verificando nova estrutura...")
            result = db.session.execute(text("SELECT sql FROM sqlite_master WHERE type='table' AND name='category'")).fetchone()
            print(f"\n   Nova estrutura SQL:")
            print(f"   {result[0] if result else 'Não encontrado'}")
            
            # 9. Testar constraint
            print("\n🧪 9. Testando nova constraint...")
            print("   ✅ Agora usuários diferentes podem ter categorias com mesmo nome!")
            print("   ✅ Mas um usuário não pode ter duas categorias com mesmo nome!")
            
            print("\n" + "=" * 70)
            print("✅ MIGRAÇÃO CONCLUÍDA COM SUCESSO!")
            print("=" * 70)
            
        except Exception as e:
            db.session.rollback()
            print(f"\n❌ ERRO durante migração: {str(e)}")
            import traceback
            traceback.print_exc()
            print("\n⚠️  Restaurando estrutura original...")
            
            # Tentar restaurar se algo deu errado
            try:
                db.session.execute(text("DROP TABLE IF EXISTS category_new"))
                db.session.commit()
                print("   ✅ Limpeza concluída")
            except:
                pass
            
            raise

if __name__ == '__main__':
    fix_category_unique_constraint()