#!/usr/bin/env python
"""Migration: Adiciona coluna image_url"""

import sys
import os
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))

from src.main import app, db
from sqlalchemy import text

def migrate():
    with app.app_context():
        try:
            # SQLite
            result = db.session.execute(text("PRAGMA table_info(template)"))
            columns = [row[1] for row in result]
            
            if 'image_url' in columns:
                print("✅ Coluna já existe!")
                return True
            
            print("📝 Adicionando coluna...")
            db.session.execute(text("ALTER TABLE template ADD COLUMN image_url TEXT"))
            db.session.commit()
            print("✅ Coluna adicionada!")
            return True
            
        except Exception as e:
            db.session.rollback()
            print(f"❌ Erro: {e}")
            return False

if __name__ == "__main__":
    migrate()