#!/usr/bin/env bash
# Arquivo: .render-build.sh (PostgreSQL - NÃO cria /data)

set -o errexit  # Encerra se algum comando falhar

echo "🚀 Iniciando build no Render (Homologação - PostgreSQL)..."

# Atualiza pip e instala dependências
echo "📦 Instalando dependências Python..."
pip install --upgrade pip
pip install -r requirements.txt

# Verifica se há migrações do Alembic
echo "🔄 Verificando migrações do banco de dados..."
if [ -d "migrations" ] && [ -f "migrations/alembic.ini" ]; then
    echo "📝 Aplicando migrações Alembic..."
    python -m flask --app src.main db upgrade || {
        echo "⚠️ Nenhuma migração Alembic a aplicar ou erro na migração"
    }
else
    echo "ℹ️  Diretório 'migrations' não encontrado - pulando Alembic"
fi

# Inicializa o banco de dados PostgreSQL (cria tabelas se não existirem)
echo "🗄️ Inicializando banco de dados PostgreSQL..."
python << 'PYTHON_SCRIPT'
import sys
import os

# Garante que o src está no path
sys.path.insert(0, os.path.dirname(__file__))

try:
    from src.main import app, db
    
    with app.app_context():
        # Importa todos os modelos
        from src.models.user import User
        from src.models.prompt import Prompt, Category, Template
        from src.models.chat import ChatPost, ChatComment, ChatLike
        
        print("📋 Criando tabelas no banco de dados PostgreSQL...")
        db.create_all()
        print("✅ Tabelas criadas com sucesso!")
        
        # Verifica se há usuário admin
        admin_count = User.query.filter_by(is_admin=True).count()
        if admin_count == 0:
            print("👤 Criando usuário admin padrão...")
            admin = User(
                email="maximizetecnologia@gmail.com",
                name="Administrador Maximize",
                is_admin=True,
                is_verified=True
            )
            admin.set_password("Max12Con*@")
            db.session.add(admin)
            db.session.commit()
            print("✅ Usuário admin criado!")
        else:
            print(f"✅ {admin_count} admin(s) já existe(m)")
            
except Exception as e:
    print(f"❌ Erro ao inicializar banco: {e}")
    import traceback
    traceback.print_exc()
    sys.exit(1)
PYTHON_SCRIPT

if [ $? -eq 0 ]; then
    echo "✅ Banco de dados PostgreSQL inicializado com sucesso!"
else
    echo "❌ Erro ao inicializar banco de dados"
    exit 1
fi

echo ""
echo "✅ Build concluído com sucesso!"
echo "🌐 Ambiente: HOMOLOGAÇÃO (Staging)"
echo "🐘 Database: PostgreSQL"
echo "🔗 Backend: https://promply-backend-staging.onrender.com"
echo "📊 Verificar logs em: https://dashboard.render.com"