import os
import sys

# Adiciona o diretório raiz do projeto (onde prompt-manager está) ao Python path
# Isso permite que 'src' seja importado como um módulo de nível superior
project_root = os.path.abspath(os.path.join(os.path.dirname(__file__), os.pardir))
sys.path.insert(0, project_root)

# Agora, importe a aplicação Flask de prompt-manager.src.main
from src.main import app

if __name__ == '__main__':
    app.run()
