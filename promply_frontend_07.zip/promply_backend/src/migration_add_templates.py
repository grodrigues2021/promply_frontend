"""
Script de migração para adicionar a tabela Template.
✅ VERSÃO CORRIGIDA - Com timeout, verificações e cleanup

Execute: python -m src.migration_add_templates
"""

import sys
import os

# Adiciona o diretório raiz ao path
sys.path.insert(0, os.path.dirname(os.path.dirname(__file__)))

from src.main import app, db
from src.models.prompt import Template

def configure_sqlite_timeout():
    """Configura timeout do SQLite para evitar locks"""
    from sqlalchemy import event
    
    @event.listens_for(db.engine, "connect")
    def set_sqlite_pragma(dbapi_conn, connection_record):
        cursor = dbapi_conn.cursor()
        cursor.execute("PRAGMA busy_timeout = 10000")  # 10 segundos
        cursor.execute("PRAGMA journal_mode = WAL")    # Write-Ahead Logging
        cursor.close()

def run_migration():
    """Cria a tabela Template se não existir"""
    
    with app.app_context():
        print("🔄 Iniciando migração de Templates...")
        
        try:
            # ✅ Configura timeout ANTES de qualquer operação
            configure_sqlite_timeout()
            
            # ✅ Verifica se tabela já existe ANTES de tentar criar
            from sqlalchemy import inspect
            inspector = inspect(db.engine)
            existing_tables = inspector.get_table_names()
            
            if 'template' in existing_tables:
                print("✅ Tabela 'template' já existe - migração não necessária")
                print(f"📊 Tabelas existentes: {', '.join(existing_tables)}")
                return True
            
            # ✅ Só cria se não existir
            print("📝 Criando tabela 'template'...")
            db.create_all()
            
            # ✅ Verifica se foi criada
            inspector = inspect(db.engine)
            tables_after = inspector.get_table_names()
            
            if 'template' in tables_after:
                print("✅ Tabela 'template' criada com sucesso!")
                print(f"📊 Tabelas no banco: {', '.join(tables_after)}")
                return True
            else:
                print("❌ Falha: Tabela 'template' não foi criada")
                return False
                
        except Exception as e:
            print(f"❌ Erro na migração: {str(e)}")
            import traceback
            traceback.print_exc()
            return False
            
        finally:
            # ✅ CRÍTICO: Sempre fecha conexões
            try:
                db.session.remove()
                db.engine.dispose()
                print("🔒 Conexões fechadas")
            except Exception as cleanup_error:
                print(f"⚠️  Erro ao fechar conexões: {cleanup_error}")


if __name__ == "__main__":
    success = run_migration()
    sys.exit(0 if success else 1)