"""
Script para executar comandos com timeout
Uso: python run_with_timeout.py "comando" tempo_em_segundos
"""
import subprocess
import sys

def run_with_timeout(cmd, timeout=60):
    """Executa comando com timeout e tratamento de erros"""
    try:
        print(f"⏱️  Executando: {cmd} (timeout: {timeout}s)")
        
        result = subprocess.run(
            cmd,
            shell=True,
            timeout=timeout,
            capture_output=True,
            text=True
        )
        
        # Exibe output
        if result.stdout:
            print(result.stdout)
        if result.stderr:
            print(result.stderr, file=sys.stderr)
        
        if result.returncode != 0:
            print(f"⚠️  Comando retornou código: {result.returncode}")
        
        return result.returncode
        
    except subprocess.TimeoutExpired:
        print(f"❌ TIMEOUT: Comando excedeu {timeout} segundos e foi abortado")
        return 124  # Código padrão de timeout
    except Exception as e:
        print(f"❌ Erro ao executar comando: {str(e)}")
        return 1

if __name__ == "__main__":
    if len(sys.argv) < 2:
        print("Uso: python run_with_timeout.py 'comando' [timeout]")
        print("Exemplo: python run_with_timeout.py 'python -m src.migration_add_templates' 30")
        sys.exit(1)
    
    cmd = sys.argv[1]
    timeout = int(sys.argv[2]) if len(sys.argv) > 2 else 60
    
    exit_code = run_with_timeout(cmd, timeout)
    sys.exit(exit_code)