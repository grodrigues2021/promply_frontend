"""
Script para popular o banco de dados com templates iniciais.
Execute: python -m src.seed_templates
"""

import sys
import os

# Adiciona o diretório raiz ao path
sys.path.insert(0, os.path.dirname(os.path.dirname(__file__)))

from src.main import app
from src.extensions import db
from src.models.prompt import Template, Category
from src.models.user import User

# Templates pré-definidos por categoria
INITIAL_TEMPLATES = {
    "Marketing": [
        {
            "title": "Post para Redes Sociais - Produto",
            "description": "Template para criar posts engajadores sobre produtos",
            "content": """Crie um post para redes sociais sobre [PRODUTO/SERVIÇO] que:

1. Comece com um gancho atrativo que desperte curiosidade
2. Destaque os 3 principais benefícios
3. Inclua um call-to-action claro
4. Use emojis relevantes
5. Adicione hashtags estratégicas

Tom: [casual/profissional/inspirador]
Público-alvo: [descreva o público]
Tamanho: [curto/médio/longo]""",
            "tags": "marketing,redes-sociais,post,instagram,facebook"
        },
        {
            "title": "Email Marketing - Promoção",
            "description": "Template para criar emails promocionais eficazes",
            "content": """Crie um email marketing para promover [PRODUTO/OFERTA] com:

**Assunto:** [Crie 3 opções de assunto impactante]

**Corpo do email:**
- Saudação personalizada
- Apresentação do problema que o produto resolve
- Destaque da oferta especial
- Prova social (depoimentos/números)
- Senso de urgência
- Call-to-action claro
- PS: Benefício adicional

Tom: [amigável/urgente/exclusivo]
Objetivo: [conversão/engajamento/awareness]""",
            "tags": "marketing,email,promoção,conversão"
        },
        {
            "title": "Descrição de Produto E-commerce",
            "description": "Template otimizado para descrições de produtos",
            "content": """Crie uma descrição persuasiva para [PRODUTO] que inclua:

**Título atrativo:** [Destaque o principal benefício]

**Introdução:** (50-70 palavras)
- Por que este produto é essencial

**Características principais:**
- [Característica 1 + benefício]
- [Característica 2 + benefício]
- [Característica 3 + benefício]

**Para quem é este produto:**
- Perfil do cliente ideal

**Diferenciais:**
- O que torna este produto único

**Especificações técnicas:**
- Detalhes relevantes

**Call-to-action:**
- Incentivo final para compra

SEO: Incluir palavras-chave naturalmente""",
            "tags": "e-commerce,produto,vendas,seo"
        }
    ],
    
    "Programação": [
        {
            "title": "Revisão de Código",
            "description": "Template para análise e revisão de código",
            "content": """Revise o seguinte código em [LINGUAGEM] e forneça:

```
[COLE O CÓDIGO AQUI]
```

Por favor, analise:

1. **Qualidade do código:**
   - Legibilidade e organização
   - Nomenclatura de variáveis e funções
   - Padrões de código (code standards)

2. **Performance:**
   - Otimizações possíveis
   - Complexidade algorítmica
   - Uso de memória

3. **Segurança:**
   - Vulnerabilidades potenciais
   - Validações necessárias

4. **Boas práticas:**
   - Design patterns aplicáveis
   - Princípios SOLID
   - Sugestões de refatoração

5. **Testes:**
   - Casos de teste necessários
   - Edge cases a considerar

Forneça exemplos de código melhorado quando aplicável.""",
            "tags": "programação,código,revisão,qualidade"
        },
        {
            "title": "Documentação de Função",
            "description": "Template para documentar funções e métodos",
            "content": """Crie documentação completa para a seguinte função em [LINGUAGEM]:

```
[COLE A FUNÇÃO AQUI]
```

A documentação deve incluir:

**Descrição:**
- O que a função faz
- Propósito e contexto de uso

**Parâmetros:**
- Nome, tipo e descrição de cada parâmetro
- Valores padrão (se houver)
- Restrições ou validações

**Retorno:**
- Tipo de retorno
- Descrição do valor retornado
- Possíveis exceções

**Exemplos de uso:**
- 2-3 exemplos práticos
- Casos comuns e edge cases

**Notas:**
- Complexidade (Big O)
- Dependências
- Considerações importantes

Formato: [JSDoc/Docstring/JavaDoc/PHPDoc]""",
            "tags": "programação,documentação,função,código"
        },
        {
            "title": "Debug - Encontrar Erro",
            "description": "Template para ajudar a debugar código",
            "content": """Ajude-me a debugar este código em [LINGUAGEM]:

**Código:**
```
[COLE O CÓDIGO AQUI]
```

**Erro encontrado:**
```
[MENSAGEM DE ERRO]
```

**Comportamento esperado:**
[Descreva o que deveria acontecer]

**Comportamento atual:**
[Descreva o que está acontecendo]

**Contexto:**
- Versão da linguagem: [versão]
- Ambiente: [desenvolvimento/produção]
- Dependências relevantes: [liste]

Por favor:
1. Identifique a causa raiz do erro
2. Explique por que está ocorrendo
3. Forneça a solução
4. Sugira como prevenir erros similares
5. Recomende melhorias no código""",
            "tags": "programação,debug,erro,solução"
        }
    ],
    
    "Escrita Criativa": [
        {
            "title": "História Curta",
            "description": "Template para escrever histórias curtas",
            "content": """Escreva uma história curta com os seguintes elementos:

**Gênero:** [ficção científica/romance/terror/aventura/drama]
**Tom:** [leve/sério/humorístico/sombrio]
**Tamanho:** [500/1000/1500 palavras]

**Elementos da história:**
- Protagonista: [descrição do personagem principal]
- Conflito central: [qual é o problema/desafio]
- Ambientação: [onde e quando se passa]
- Tema: [mensagem ou ideia central]

**Estrutura:**
1. Introdução: Apresente o personagem e contexto
2. Desenvolvimento: Construa o conflito
3. Clímax: Momento de maior tensão
4. Resolução: Conclusão satisfatória

**Estilo:**
- Use diálogos naturais
- Descrições sensoriais
- Mostre, não conte
- Crie empatia com os personagens""",
            "tags": "escrita,história,criativo,narrativa"
        },
        {
            "title": "Artigo de Blog",
            "description": "Template para escrever artigos de blog envolventes",
            "content": """Escreva um artigo de blog sobre [TÓPICO] com:

**Título:** [Crie um título chamativo e otimizado para SEO]

**Meta descrição:** (150-160 caracteres)
[Resumo atrativo do artigo]

**Estrutura do artigo:**

1. **Introdução** (100-150 palavras)
   - Hook inicial
   - Apresentação do problema
   - Promessa de valor

2. **Desenvolvimento** (800-1200 palavras)
   - Subtópico 1: [Ponto principal]
   - Subtópico 2: [Ponto principal]
   - Subtópico 3: [Ponto principal]
   - Exemplos práticos
   - Dados e estatísticas

3. **Conclusão** (100-150 palavras)
   - Resumo dos pontos principais
   - Call-to-action
   - Próximos passos

**Tom:** [informativo/conversacional/técnico]
**Público-alvo:** [iniciante/intermediário/avançado]
**Palavras-chave SEO:** [liste 3-5 palavras-chave]""",
            "tags": "blog,artigo,seo,conteúdo"
        }
    ],
    
    "Produtividade": [
        {
            "title": "Resumo de Reunião",
            "description": "Template para resumir reuniões de forma eficiente",
            "content": """Crie um resumo estruturado da reunião com base nas seguintes notas:

[COLE AS NOTAS DA REUNIÃO AQUI]

**Formato do resumo:**

**Informações básicas:**
- Data: [data]
- Participantes: [lista]
- Duração: [tempo]

**Tópicos discutidos:**
1. [Tópico 1]
   - Pontos principais
   - Decisões tomadas
   
2. [Tópico 2]
   - Pontos principais
   - Decisões tomadas

**Ações definidas:**
- [ ] Ação 1 - Responsável: [nome] - Prazo: [data]
- [ ] Ação 2 - Responsável: [nome] - Prazo: [data]

**Pendências:**
- Item 1
- Item 2

**Próximos passos:**
- [Próxima reunião/marcos]

**Observações importantes:**
- [Notas relevantes]""",
            "tags": "reunião,produtividade,resumo,trabalho"
        },
        {
            "title": "Planejamento Semanal",
            "description": "Template para organizar sua semana",
            "content": """Crie um planejamento semanal eficiente:

**Semana de:** [data inicial] a [data final]

**Objetivos da semana:**
1. [Objetivo prioritário 1]
2. [Objetivo prioritário 2]
3. [Objetivo prioritário 3]

**Segunda-feira:**
- 🎯 Foco: [área principal]
- Tarefas:
  - [ ] Tarefa importante
  - [ ] Tarefa importante
- Reuniões: [horários]

**Terça-feira:**
- 🎯 Foco: [área principal]
- Tarefas:
  - [ ] Tarefa importante
- Reuniões: [horários]

**Quarta-feira:**
- 🎯 Foco: [área principal]
- Tarefas:
  - [ ] Tarefa importante
- Reuniões: [horários]

**Quinta-feira:**
- 🎯 Foco: [área principal]
- Tarefas:
  - [ ] Tarefa importante
- Reuniões: [horários]

**Sexta-feira:**
- 🎯 Foco: [área principal]
- Tarefas:
  - [ ] Tarefa importante
  - [ ] Revisão semanal
- Reuniões: [horários]

**Blocos de tempo reservados:**
- Deep Work: [horários]
- Emails/Admin: [horários]
- Pausas: [horários]

**Lembretes importantes:**
- [Deadlines]
- [Compromissos]""",
            "tags": "planejamento,produtividade,organização,semana"
        }
    ]
}


def seed_templates():
    """Popula o banco com templates iniciais"""
    
    with app.app_context():
        # ✅ VERIFICAÇÃO: Não popular se já existem templates
        existing_templates = Template.query.count()
        
        if existing_templates > 0:
            print(f"⏭️  Templates já existem ({existing_templates} encontrados).")
            print("   Pulando população para não duplicar dados.")
            return
        
        print("🌱 Iniciando população de templates...")
        
        # Busca o usuário admin
        admin = User.query.filter_by(is_admin=True).first()
        
        if not admin:
            print("❌ Erro: Nenhum usuário admin encontrado!")
            print("   Crie um admin primeiro antes de executar este script.")
            return
        
        print(f"✅ Admin encontrado: {admin.email}")
        
        # Para cada categoria
        for category_name, templates in INITIAL_TEMPLATES.items():
            # Busca ou cria a categoria
            category = Category.query.filter_by(name=category_name).first()
            
            if not category:
                # Define cores por categoria
                colors = {
                    "Marketing": "#FF6B6B",
                    "Programação": "#4ECDC4",
                    "Escrita Criativa": "#95E1D3",
                    "Produtividade": "#F38181"
                }
                
                category = Category(
                    name=category_name,
                    description=f"Templates de {category_name}",
                    color=colors.get(category_name, "#3B82F6"),
                    is_template=True,
                    user_id=None  # Categorias de template não pertencem a ninguém
                )
                db.session.add(category)
                db.session.commit()
                print(f"✅ Categoria criada: {category_name}")
            else:
                print(f"ℹ️  Categoria já existe: {category_name}")
            
            # Cria templates para esta categoria
            for template_data in templates:
                # Verifica se template já existe
                existing = Template.query.filter_by(
                    title=template_data['title'],
                    category_id=category.id
                ).first()
                
                if existing:
                    print(f"   ⏭️  Template já existe: {template_data['title']}")
                    continue
                
                # Cria novo template
                new_template = Template(
                    title=template_data['title'],
                    content=template_data['content'],
                    description=template_data['description'],
                    tags=template_data['tags'],
                    category_id=category.id,
                    created_by=admin.id,
                    is_active=True
                )
                
                db.session.add(new_template)
                print(f"   ✅ Template criado: {template_data['title']}")
            
            db.session.commit()
        
        print("\n🎉 População de templates concluída com sucesso!")
        print(f"📊 Total de templates: {Template.query.count()}")


if __name__ == "__main__":
    seed_templates()