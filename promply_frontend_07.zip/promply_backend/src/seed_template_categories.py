"""
Script para criar apenas as categorias de templates.
Útil se você já tem templates mas sem categorias.
Execute: python -m src.seed_template_categories
"""

import sys
import os

sys.path.insert(0, os.path.dirname(os.path.dirname(__file__)))

from src.main import app
from src.extensions import db
from src.models.prompt import Category

# Categorias padrão para templates
TEMPLATE_CATEGORIES = {
    "Marketing": {
        "description": "Templates de Marketing e Comunicação",
        "color": "#FF6B6B"
    },
    "Programação": {
        "description": "Templates de Programação e Desenvolvimento",
        "color": "#4ECDC4"
    },
    "Escrita Criativa": {
        "description": "Templates de Escrita e Conteúdo",
        "color": "#95E1D3"
    },
    "Produtividade": {
        "description": "Templates de Produtividade e Organização",
        "color": "#F38181"
    },
    "Vendas": {
        "description": "Templates de Vendas e Comercial",
        "color": "#A8E6CF"
    },
    "Atendimento": {
        "description": "Templates de Atendimento ao Cliente",
        "color": "#FFD3B6"
    },
    "RH": {
        "description": "Templates de Recursos Humanos",
        "color": "#FFAAA5"
    },
    "Educação": {
        "description": "Templates Educacionais",
        "color": "#C7CEEA"
    }
}


def seed_categories():
    """Cria categorias de templates"""
    
    with app.app_context():
        print("📁 Criando categorias de templates...\n")
        
        created = 0
        existing = 0
        
        for name, data in TEMPLATE_CATEGORIES.items():
            # Verifica se já existe (busca por nome E is_template)
            category = Category.query.filter_by(
                name=name, 
                is_template=True
            ).first()
            
            if category:
                print(f"   ⏭️  Categoria já existe: {name}")
                existing += 1
            else:
                # Cria nova categoria
                new_category = Category(
                    name=name,
                    description=data["description"],
                    color=data["color"],
                    is_template=True,
                    user_id=None  # Categorias de template não pertencem a ninguém
                )
                db.session.add(new_category)
                print(f"   ✅ Categoria criada: {name}")
                created += 1
        
        db.session.commit()
        
        print(f"\n📊 Resumo:")
        print(f"   ✅ Categorias criadas: {created}")
        print(f"   ⏭️  Categorias existentes: {existing}")
        print(f"   📁 Total: {created + existing}")
        print("\n✅ Processo concluído!")


if __name__ == "__main__":
    seed_categories()
