import boto3
import os

# Cria uma sessão padrão
session = boto3.session.Session()

# Cliente configurado para o endpoint do Backblaze (compatível com S3)
s3_client = session.client(
    service_name='s3',
    endpoint_url=os.getenv('B2_ENDPOINT'),
    aws_access_key_id=os.getenv('B2_KEY_ID'),
    aws_secret_access_key=os.getenv('B2_APPLICATION_KEY'),
)

def upload_file_to_b2(file_path, object_name):
    """
    Envia um arquivo local para o bucket configurado no Backblaze B2.
    Retorna a URL pública (ou privada) do arquivo.
    """
    bucket_name = os.getenv('B2_BUCKET_NAME')

    s3_client.upload_file(file_path, bucket_name, object_name)

    # Retorna a URL completa do arquivo no B2
    return f"{os.getenv('B2_ENDPOINT')}/{bucket_name}/{object_name}"

def delete_file_from_b2(object_name):
    """
    Exclui um arquivo do bucket B2.
    """
    bucket_name = os.getenv('B2_BUCKET_NAME')
    s3_client.delete_object(Bucket=bucket_name, Key=object_name)
