import os
from flask_sqlalchemy import SQLAlchemy


db = SQLAlchemy()


def get_database_url():
database_url = os.getenv("DATABASE_URL")
if database_url:
# Render ainda usa prefixo postgres://
if database_url.startswith("postgres://"):
database_url = database_url.replace("postgres://", "postgresql://", 1)
return database_url


# fallback local
return "sqlite:///./instance/app.db"