"""
Rotas da API para o sistema de chat interno
Arquivo: prompt_manager/src/routes/chat.py
"""

from flask import Blueprint, request, jsonify
from flask_jwt_extended import jwt_required, get_jwt_identity
from src.extensions import db
from src.models.chat import ChatPost, ChatComment, ChatLike
from src.models.prompt import Prompt
from src.models.user import User
from datetime import datetime

chat_bp = Blueprint('chat', __name__)


# ============================================
# POSTS
# ============================================

@chat_bp.route('/posts', methods=['GET'])
@jwt_required()
def get_posts():
    """Lista todos os posts do chat (ordenados por data decrescente)"""
    try:
        current_user_id = get_jwt_identity()
        page = request.args.get('page', 1, type=int)
        per_page = request.args.get('per_page', 20, type=int)
        
        pagination = ChatPost.query.order_by(
            ChatPost.created_at.asc()
        ).paginate(
            page=page,
            per_page=per_page,
            error_out=False
        )
        
        posts = [post.to_dict(current_user_id) for post in pagination.items]
        
        return jsonify({
            'success': True,
            'data': posts,
            'pagination': {
                'page': pagination.page,
                'per_page': pagination.per_page,
                'total': pagination.total,
                'pages': pagination.pages
            }
        }), 200
        
    except Exception as e:
        return jsonify({
            'success': False,
            'message': f'Erro ao buscar posts: {str(e)}'
        }), 500


@chat_bp.route('/posts', methods=['POST'])
@jwt_required()
def create_post():
    """Cria um novo post no chat"""
    try:
        current_user_id = get_jwt_identity()
        data = request.get_json()
        
        if not data or 'content' not in data:
            return jsonify({
                'success': False,
                'message': 'Conteúdo do post é obrigatório'
            }), 400
        
        content = data['content'].strip()
        if len(content) < 1:
            return jsonify({
                'success': False,
                'message': 'O post não pode estar vazio'
            }), 400
        
        if len(content) > 5000:
            return jsonify({
                'success': False,
                'message': 'O post não pode ter mais de 5000 caracteres'
            }), 400
        
        new_post = ChatPost(
            author_id=current_user_id,
            content=content
        )
        
        db.session.add(new_post)
        db.session.commit()
        
        return jsonify({
            'success': True,
            'message': 'Post criado com sucesso!',
            'data': new_post.to_dict(current_user_id)
        }), 201
        
    except Exception as e:
        db.session.rollback()
        return jsonify({
            'success': False,
            'message': f'Erro ao criar post: {str(e)}'
        }), 500


@chat_bp.route('/posts/<int:post_id>', methods=['DELETE'])
@jwt_required()
def delete_post(post_id):
    """Deleta um post (apenas o autor ou admin pode deletar)"""
    try:
        current_user_id = get_jwt_identity()
        user = User.query.get(current_user_id)
        post = ChatPost.query.get_or_404(post_id)
        
        if post.author_id != current_user_id and not user.is_admin:
            return jsonify({
                'success': False,
                'message': 'Você não tem permissão para deletar este post'
            }), 403
        
        db.session.delete(post)
        db.session.commit()
        
        return jsonify({
            'success': True,
            'message': 'Post deletado com sucesso'
        }), 200
        
    except Exception as e:
        db.session.rollback()
        return jsonify({
            'success': False,
            'message': f'Erro ao deletar post: {str(e)}'
        }), 500


# ============================================
# COMMENTS
# ============================================

@chat_bp.route('/posts/<int:post_id>/comments', methods=['GET'])
@jwt_required()
def get_comments(post_id):
    """Lista todos os comentários de um post"""
    try:
        post = ChatPost.query.get_or_404(post_id)
        comments = ChatComment.query.filter_by(
            post_id=post_id
        ).order_by(
            ChatComment.created_at.asc()
        ).all()
        
        return jsonify({
            'success': True,
            'data': [comment.to_dict() for comment in comments]
        }), 200
        
    except Exception as e:
        return jsonify({
            'success': False,
            'message': f'Erro ao buscar comentários: {str(e)}'
        }), 500


@chat_bp.route('/posts/<int:post_id>/comments', methods=['POST'])
@jwt_required()
def create_comment(post_id):
    """Cria um comentário em um post"""
    try:
        current_user_id = get_jwt_identity()
        post = ChatPost.query.get_or_404(post_id)
        data = request.get_json()
        
        if not data or 'content' not in data:
            return jsonify({
                'success': False,
                'message': 'Conteúdo do comentário é obrigatório'
            }), 400
        
        content = data['content'].strip()
        if len(content) < 1:
            return jsonify({
                'success': False,
                'message': 'O comentário não pode estar vazio'
            }), 400
        
        if len(content) > 2000:
            return jsonify({
                'success': False,
                'message': 'O comentário não pode ter mais de 2000 caracteres'
            }), 400
        
        new_comment = ChatComment(
            post_id=post_id,
            author_id=current_user_id,
            content=content
        )
        
        db.session.add(new_comment)
        db.session.commit()
        
        return jsonify({
            'success': True,
            'message': 'Comentário adicionado!',
            'data': new_comment.to_dict()
        }), 201
        
    except Exception as e:
        db.session.rollback()
        return jsonify({
            'success': False,
            'message': f'Erro ao criar comentário: {str(e)}'
        }), 500


@chat_bp.route('/comments/<int:comment_id>', methods=['DELETE'])
@jwt_required()
def delete_comment(comment_id):
    """Deleta um comentário (apenas o autor ou admin)"""
    try:
        current_user_id = get_jwt_identity()
        user = User.query.get(current_user_id)
        comment = ChatComment.query.get_or_404(comment_id)
        
        if comment.author_id != current_user_id and not user.is_admin:
            return jsonify({
                'success': False,
                'message': 'Você não tem permissão para deletar este comentário'
            }), 403
        
        db.session.delete(comment)
        db.session.commit()
        
        return jsonify({
            'success': True,
            'message': 'Comentário deletado'
        }), 200
        
    except Exception as e:
        db.session.rollback()
        return jsonify({
            'success': False,
            'message': f'Erro ao deletar comentário: {str(e)}'
        }), 500


# ============================================
# LIKES
# ============================================

@chat_bp.route('/posts/<int:post_id>/like', methods=['POST'])
@jwt_required()
def toggle_like(post_id):
    """Adiciona ou remove like de um post (toggle)"""
    try:
        current_user_id = get_jwt_identity()
        post = ChatPost.query.get_or_404(post_id)
        
        existing_like = ChatLike.query.filter_by(
            user_id=current_user_id,
            post_id=post_id
        ).first()
        
        if existing_like:
            db.session.delete(existing_like)
            db.session.commit()
            
            return jsonify({
                'success': True,
                'message': 'Like removido',
                'liked': False,
                'likes_count': post.likes.count()
            }), 200
        else:
            new_like = ChatLike(
                user_id=current_user_id,
                post_id=post_id
            )
            db.session.add(new_like)
            db.session.commit()
            
            return jsonify({
                'success': True,
                'message': 'Post curtido!',
                'liked': True,
                'likes_count': post.likes.count()
            }), 201
            
    except Exception as e:
        db.session.rollback()
        return jsonify({
            'success': False,
            'message': f'Erro ao processar like: {str(e)}'
        }), 500


# ============================================
# SAVE TO CATEGORY - ✅ ATUALIZADO
# ============================================

@chat_bp.route('/posts/<int:post_id>/save', methods=['POST'])
@jwt_required()
def save_to_category(post_id):
    """Salva o conteúdo de um post como prompt pessoal"""
    try:
        current_user_id = get_jwt_identity()
        post = ChatPost.query.get_or_404(post_id)
        data = request.get_json() or {}
        
        print(f"💾 SAVE TO CATEGORY - Post ID: {post_id}")
        print(f"   Shared Prompt ID: {post.shared_prompt_id}")
        
        # ✅ CORRIGIDO: Verificar se é post de prompt compartilhado
        if post.shared_prompt_id:
            # Post veio de compartilhamento - usar estrutura original
            original_prompt = Prompt.query.get(post.shared_prompt_id)
            
            if not original_prompt:
                print(f"   ❌ Prompt original {post.shared_prompt_id} não encontrado")
                return jsonify({
                    'success': False,
                    'message': 'Prompt original não encontrado'
                }), 404
            
            print(f"   ✅ Usando prompt original: {original_prompt.title}")
            
            # ✅ Criar mantendo estrutura original
            new_prompt = Prompt(
                title=data.get('title', original_prompt.title),
                content=original_prompt.content,  # ✅ Conteúdo original
                description=original_prompt.description or '',  # ✅ Descrição original
                tags=original_prompt.tags or '',  # ✅ Tags originais
                user_id=current_user_id,
                category_id=data.get('category_id'),
                is_favorite=data.get('is_favorite', False)
            )
            
            print(f"   📝 Prompt criado:")
            print(f"      Título: {new_prompt.title}")
            print(f"      Descrição: {new_prompt.description}")
            print(f"      Tags: {new_prompt.tags}")
        else:
            # Post normal (não compartilhado) - usar conteúdo do post
            print(f"   ℹ️  Post normal (não compartilhado)")
            
            new_prompt = Prompt(
                title=data.get('title', f'Prompt do Chat - {post.author.name}'),
                content=post.content,
                description=f'Salvo do chat em {datetime.now().strftime("%d/%m/%Y")}',
                tags='',
                user_id=current_user_id,
                category_id=data.get('category_id'),
                is_favorite=data.get('is_favorite', False)
            )
        
        db.session.add(new_prompt)
        db.session.commit()
        
        print(f"   ✅ Prompt salvo com sucesso! ID: {new_prompt.id}")
        
        return jsonify({
            'success': True,
            'message': 'Prompt salvo nas suas categorias!',
            'data': new_prompt.to_dict()
        }), 201
        
    except Exception as e:
        db.session.rollback()
        print(f"   ❌ Erro ao salvar: {str(e)}")
        import traceback
        traceback.print_exc()
        return jsonify({
            'success': False,
            'message': f'Erro ao salvar prompt: {str(e)}'
        }), 500


# ============================================
# SHARE PROMPT - ✅ ATUALIZADO
# ============================================

@chat_bp.route('/share-prompt/<int:prompt_id>', methods=['POST'])
@jwt_required()
def share_prompt(prompt_id):
    """Compartilha um prompt pessoal no chat público"""
    try:
        current_user_id = get_jwt_identity()
        
        print(f"📤 SHARE PROMPT - ID: {prompt_id}")
        print(f"   User ID: {current_user_id}")
        
        prompt = Prompt.query.get_or_404(prompt_id)
        
        print(f"   Prompt User ID: {prompt.user_id}")
        
        # Verificar propriedade
        if int(prompt.user_id) != int(current_user_id):
            print(f"   ❌ Permissão negada!")
            return jsonify({
                'success': False,
                'message': 'Você não tem permissão para compartilhar este prompt'
            }), 403
        
        print(f"   ✅ Permissão OK!")
        
        data = request.get_json() or {}
        message = data.get('message', '').strip()
        
        # ✅ ATUALIZADO: Apenas a mensagem do usuário no content
        # O prompt fica separado via shared_prompt_id
        post_content = message if message else f"Compartilhei o prompt: {prompt.title}"
        
        # ✅ Criar post COM referência ao prompt original
        new_post = ChatPost(
            author_id=current_user_id,
            content=post_content,  # ✅ Apenas mensagem do usuário
            shared_prompt_id=prompt_id  # ✅ Referência ao prompt
        )
        
        db.session.add(new_post)
        db.session.commit()
        
        print(f"   ✅ Post criado: ID {new_post.id}")
        print(f"   📌 Shared Prompt ID: {new_post.shared_prompt_id}")
        
        return jsonify({
            'success': True,
            'message': 'Prompt compartilhado no chat!',
            'data': new_post.to_dict(current_user_id)
        }), 201
        
    except Exception as e:
        db.session.rollback()
        print(f"   ❌ Erro: {str(e)}")
        import traceback
        traceback.print_exc()
        return jsonify({
            'success': False,
            'message': f'Erro ao compartilhar prompt: {str(e)}'
        }), 500
