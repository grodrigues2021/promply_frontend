from flask import Blueprint, request, jsonify, url_for, redirect, make_response, current_app
from src.extensions import db, jwt, oauth
from src.models.user import User
from src.models.prompt import Category
from flask_jwt_extended import (
    create_access_token,
    jwt_required,
    get_jwt_identity,
    set_access_cookies,
    unset_jwt_cookies,
)
from flask_mail import Message
import os, secrets
from datetime import datetime, timedelta

auth_bp = Blueprint("auth", __name__)

# =========================
# Registro com verificação de e-mail
# =========================
@auth_bp.route("/register", methods=["POST"])
def register():
    data = request.get_json() or {}
    email = data.get("email")
    password = data.get("password")
    name = data.get("name")

    if not email or not password or not name:
        return jsonify({"success": False, "error": "Nome, email e senha são obrigatórios"}), 400

    if User.query.filter_by(email=email).first():
        return jsonify({"success": False, "error": "Email já registrado"}), 409

    # cria usuário com verificação pendente
    new_user = User(email=email, name=name, is_verified=False)
    new_user.set_password(password)

    # gera token único e salva no banco
    token = secrets.token_urlsafe(32)
    new_user.verify_token = token

    db.session.add(new_user)
    db.session.commit()

    # cria link de verificação completo (HTTPS para Render)
    verify_link = f"{request.host_url.rstrip('/')}/api/auth/verify/{token}"

    # envia o e-mail de verificação
    try:
        from src.main import mail
        msg = Message(
            subject="Confirme seu e-mail - Promply.app",
            recipients=[email],
            body=(
                f"Olá, {name}!\n\n"
                f"Clique no link abaixo para confirmar seu e-mail e ativar sua conta:\n\n"
                f"{verify_link}\n\n"
                f"Se você não criou uma conta no Promply, ignore esta mensagem."
            ),
        )
        mail.send(msg)
    except Exception as e:
        current_app.logger.error(f"Erro ao enviar e-mail de verificação: {e}")
        return jsonify({"success": False, "error": "Não foi possível enviar o e-mail de verificação."}), 500

    return jsonify({"success": True, "message": "Conta criada! Verifique seu e-mail para ativá-la."}), 201


# =========================
# Verificação do e-mail
# =========================
@auth_bp.route("/verify/<token>", methods=["GET"])
def verify_email(token):
    user = User.query.filter_by(verify_token=token).first()

    if not user:
        return "<h2>❌ Link inválido ou expirado.</h2>", 400

    user.is_verified = True
    user.verify_token = None
    db.session.commit()

    return "<h2>✅ E-mail verificado com sucesso! Agora você pode fazer login.</h2>", 200


# =========================
# Login (email/senha)
# =========================
@auth_bp.route("/login", methods=["POST", "OPTIONS"])
def login():
    if request.method == "OPTIONS":
        return ("", 204)

    data = request.get_json() or {}
    email = data.get("email")
    password = data.get("password")

    if not email or not password:
        return jsonify({"success": False, "error": "Email e senha são obrigatórios"}), 400

    user = User.query.filter_by(email=email).first()
    if not user:
        return jsonify({"success": False, "error": "Usuário não encontrado."}), 404

    # impede login de usuários não verificados
    if not user.is_verified:
        return jsonify({"success": False, "error": "E-mail ainda não verificado. Verifique sua caixa de entrada."}), 403

    if user.check_password(password):
        access_token = create_access_token(identity=str(user.id))
        resp = jsonify({"success": True, "data": user.to_dict()})
        set_access_cookies(resp, access_token, max_age=60 * 60 * 24)
        return resp

    return jsonify({"success": False, "error": "Credenciais inválidas"}), 401


# =========================
# Esqueci a senha - Solicitar reset
# =========================
@auth_bp.route("/forgot-password", methods=["POST"])
def forgot_password():
    data = request.get_json() or {}
    email = data.get("email")

    if not email:
        return jsonify({"success": False, "error": "Email é obrigatório"}), 400

    user = User.query.filter_by(email=email).first()
    
    if not user:
        return jsonify({"success": True, "message": "Se o email existir, você receberá um link de recuperação."}), 200

    reset_token = secrets.token_urlsafe(32)
    user.reset_token = reset_token
    user.reset_token_expires = datetime.utcnow() + timedelta(hours=1)
    
    db.session.commit()

    reset_link = f"{request.host_url.rstrip('/')}/api/auth/reset-password?token={reset_token}"

    try:
        from src.main import mail
        msg = Message(
            subject="Recuperação de senha - Promply.app",
            recipients=[email],
            body=(
                f"Olá, {user.name}!\n\n"
                f"Você solicitou a recuperação de senha da sua conta no Promply.app.\n\n"
                f"Clique no link abaixo para redefinir sua senha:\n\n"
                f"{reset_link}\n\n"
                f"Este link expira em 1 hora.\n\n"
                f"Se você não solicitou esta recuperação, ignore este e-mail."
            ),
        )
        mail.send(msg)
    except Exception as e:
        current_app.logger.error(f"Erro ao enviar e-mail de recuperação: {e}")
        return jsonify({"success": False, "error": "Não foi possível enviar o e-mail de recuperação."}), 500

    return jsonify({"success": True, "message": "Se o email existir, você receberá um link de recuperação."}), 200


# =========================
# Resetar senha
# =========================
@auth_bp.route("/reset-password", methods=["POST"])
def reset_password():
    data = request.get_json() or {}
    token = data.get("token")
    new_password = data.get("password")

    if not token or not new_password:
        return jsonify({"success": False, "error": "Token e nova senha são obrigatórios"}), 400

    user = User.query.filter_by(reset_token=token).first()

    if not user:
        return jsonify({"success": False, "error": "Token inválido ou expirado"}), 400

    if user.reset_token_expires and user.reset_token_expires < datetime.utcnow():
        return jsonify({"success": False, "error": "Token expirado. Solicite um novo link de recuperação."}), 400

    user.set_password(new_password)
    user.reset_token = None
    user.reset_token_expires = None
    
    db.session.commit()

    return jsonify({"success": True, "message": "Senha redefinida com sucesso! Você pode fazer login agora."}), 200


# =========================
# Usuário atual
# =========================
@auth_bp.route("/me", methods=["GET"])
@jwt_required()
def get_current_user():
    current_user_id = int(get_jwt_identity())
    user = User.query.get(current_user_id)
    if user:
        return jsonify({"success": True, "data": user.to_dict()}), 200
    return jsonify({"success": False, "error": "Usuário não encontrado"}), 404


# =========================
# 🔥 LOGIN COM GOOGLE - CORRIGIDO
# =========================
# =========================
# 🔥 LOGIN COM GOOGLE - CORRIGIDO PARA PRODUÇÃO
# =========================
@auth_bp.route("/login/google", methods=["GET"])
def login_google():
    """Inicia o fluxo de autenticação OAuth do Google"""
    print("🚀 Iniciando login com Google...")
    
    # ✅ Detecta ambiente automaticamente
    is_local = request.host.startswith('localhost') or request.host.startswith('127.0.0.1')
    
    # ✅ URL de callback correta baseada no ambiente
    if is_local:
        redirect_uri = url_for("auth.authorize_google", _external=True, _scheme="http")
    else:
        # Produção/Staging - sempre HTTPS
        redirect_uri = url_for("auth.authorize_google", _external=True, _scheme="https")
    
    print(f"🔗 Redirect URI: {redirect_uri}")
    
    return oauth.google.authorize_redirect(redirect_uri)


@auth_bp.route("/login/google/authorized", methods=["GET"])
def authorize_google():
    """Callback do Google OAuth - recebe o código de autorização"""
    print("📥 Callback do Google recebido...")
    
    try:
        # Obtém o token de acesso do Google
        token = oauth.google.authorize_access_token()
        print(f"✅ Token recebido: {token.get('access_token', 'N/A')[:20]}...")
        
        # Busca informações do usuário no Google
        resp = oauth.google.get('https://www.googleapis.com/oauth2/v3/userinfo')
        userinfo = resp.json()
        print(f"👤 Userinfo: {userinfo.get('email')}")
        
        # Busca ou cria o usuário no banco de dados
        user = User.query.filter_by(google_id=userinfo["sub"]).first()
        
        if not user:
            # Verifica se já existe usuário com este email
            user = User.query.filter_by(email=userinfo["email"]).first()
            
            if user:
                # Vincula conta existente ao Google
                user.google_id = userinfo["sub"]
                user.is_verified = True
                print(f"🔗 Vinculando conta existente: {user.email}")
            else:
                # Cria novo usuário
                user = User(
                    email=userinfo["email"],
                    name=userinfo.get("name") or userinfo.get("given_name") or "Usuário Google",
                    google_id=userinfo["sub"],
                    is_verified=True,
                )
                db.session.add(user)
                print(f"✨ Novo usuário criado: {user.email}")
            
            db.session.commit()
        
        # Cria token JWT
        access_token = create_access_token(identity=str(user.id))
        
        # ✅ Detecta ambiente e redireciona para o frontend correto
        is_local = request.host.startswith('localhost') or request.host.startswith('127.0.0.1')
        
        if is_local:
            frontend_url = "http://localhost:5173"
        elif 'api-staging.promply.app' in request.host:
            frontend_url = "https://app-staging.promply.app"
        elif 'promply-backend-staging' in request.host:
            frontend_url = "https://promply-frontend-staging.onrender.com"
        else:
            # Produção
            frontend_url = "https://app.promply.app"
        
        resp = make_response(redirect(frontend_url))
        set_access_cookies(resp, access_token, max_age=60 * 60 * 24)
        
        print(f"✅ Login com Google concluído! Redirecionando para {frontend_url}")
        return resp
        
    except Exception as e:
        print(f"❌ Erro no login com Google: {str(e)}")
        import traceback
        traceback.print_exc()
        
        # ✅ Redireciona para o frontend correto com erro
        is_local = request.host.startswith('localhost') or request.host.startswith('127.0.0.1')
        
        if is_local:
            error_url = "http://localhost:5173?error=google_auth_failed"
        elif 'api-staging.promply.app' in request.host:
            error_url = "https://app-staging.promply.app?error=google_auth_failed"
        elif 'promply-backend-staging' in request.host:
            error_url = "https://promply-frontend-staging.onrender.com?error=google_auth_failed"
        else:
            error_url = "https://app.promply.app?error=google_auth_failed"
        
        return redirect(error_url)
        
        # Cria token JWT
        access_token = create_access_token(identity=str(user.id))
        
        # Redireciona para o frontend com cookie
        frontend_url = "http://localhost:5173"
        resp = make_response(redirect(frontend_url))
        set_access_cookies(resp, access_token, max_age=60 * 60 * 24)
        
        print(f"✅ Login com Google concluído! Redirecionando para {frontend_url}")
        return resp
        
    except Exception as e:
        print(f"❌ Erro no login com Google: {str(e)}")
        import traceback
        traceback.print_exc()
        
        # Redireciona para o frontend com erro
        error_url = f"http://localhost:5173?error=google_auth_failed"
        return redirect(error_url)


# =========================
# Logout
# =========================
@auth_bp.route("/logout", methods=["POST", "GET", "OPTIONS"])
def logout():
    """Remove os cookies JWT e encerra a sessão"""
    if request.method == "OPTIONS":
        response = make_response()
        origin = request.headers.get('Origin', '*')
        response.headers.add('Access-Control-Allow-Origin', origin)
        response.headers.add('Access-Control-Allow-Credentials', 'true')
        response.headers.add('Access-Control-Allow-Methods', 'POST, GET, OPTIONS')
        response.headers.add('Access-Control-Allow-Headers', 'Content-Type, Authorization')
        return response, 200
    
    try:
        print("🚪 Backend: Processando logout...")
        
        try:
            user_id = get_jwt_identity()
            if user_id:
                print(f"👤 Backend: Logout do usuário ID {user_id}")
        except:
            print("⚠️ Backend: Logout sem JWT válido")
        
        resp = make_response(jsonify({
            "success": True, 
            "message": "Logout efetuado com sucesso"
        }), 200)
        
        unset_jwt_cookies(resp)
        
        cookie_names = [
            'access_token_cookie',
            'refresh_token_cookie', 
            'csrf_access_token',
            'csrf_refresh_token',
            'session'
        ]
        
        for cookie_name in cookie_names:
            resp.set_cookie(
                cookie_name, 
                '', 
                expires=0,
                max_age=0,
                secure=False,  # HTTP para localhost
                httponly=True, 
                samesite='Lax',  # Lax para localhost
                path='/'
            )
        
        origin = request.headers.get('Origin')
        if origin:
            resp.headers.add('Access-Control-Allow-Origin', origin)
        resp.headers.add('Access-Control-Allow-Credentials', 'true')
        
        print("✅ Backend: Logout concluído")
        return resp
        
    except Exception as e:
        print(f"❌ Backend: Erro no logout: {str(e)}")
        import traceback
        traceback.print_exc()
        
        resp = make_response(jsonify({
            "success": False,
            "error": str(e),
            "message": "Erro no logout, mas tentando limpar cookies"
        }), 500)
        
        try:
            unset_jwt_cookies(resp)
        except:
            pass
            
        return resp


# =========================
# Promover usuário a administrador
# =========================
@auth_bp.route("/promote-admin", methods=["POST"])
def promote_admin():
    data = request.get_json() or {}
    email = data.get("email")
    secret_key = data.get("secret_key")

    if not email or not secret_key:
        return jsonify({"success": False, "error": "Email e chave secreta são obrigatórios"}), 400

    admin_promotion_secret = os.getenv("ADMIN_PROMOTION_SECRET")
    if not admin_promotion_secret or secret_key != admin_promotion_secret:
        return jsonify({"success": False, "error": "Chave secreta inválida"}), 403

    user = User.query.filter_by(email=email).first()
    if not user:
        return jsonify({"success": False, "error": "Usuário não encontrado"}), 404

    user.is_admin = True
    db.session.commit()

    return jsonify({"success": True, "message": f"Usuário {email} promovido a administrador com sucesso!"}), 200