from flask import Blueprint, request, jsonify
from src.extensions import db
from src.models.prompt import Category
from src.models.user import User
from flask_jwt_extended import jwt_required, get_jwt_identity

category_bp = Blueprint('category', __name__)

# =====================================================
# LISTAR CATEGORIAS - ✅ CORRIGIDO
# =====================================================
@category_bp.route("/", methods=["GET"])
@jwt_required()
def get_categories():
    """Retorna categorias do usuário e templates do admin"""
    try:
        current_user_id = get_jwt_identity()
        user = User.query.get(current_user_id)
        
        if not user:
            return jsonify({"success": False, "error": "Usuário não encontrado"}), 404

        # Categorias do usuário (pessoais)
        user_categories = Category.query.filter_by(
            user_id=current_user_id, 
            is_template=False
        ).order_by(Category.name).all()

        # Templates criados por administradores
        template_categories = Category.query.filter_by(
            is_template=True
        ).order_by(Category.name).all()

        # ✅ CORRIGIDO: Combinar tudo em uma lista "data"
        all_categories = [c.to_dict() for c in user_categories] + [t.to_dict() for t in template_categories]

        return jsonify({
            "success": True,
            "data": all_categories,  # ✅ Padrão da API
            # Manter compatibilidade com código antigo (opcional)
            "categories": [c.to_dict() for c in user_categories],
            "templates": [t.to_dict() for t in template_categories]
        }), 200

    except Exception as e:
        print(f"❌ Erro em get_categories: {str(e)}")
        import traceback
        traceback.print_exc()
        return jsonify({
            "success": False,
            "error": str(e)
        }), 500


# =====================================================
# CRIAR CATEGORIA - ✅ CORRIGIDO
# =====================================================
@category_bp.route("/", methods=["POST"])
@jwt_required()
def create_category():
    try:
        current_user_id = get_jwt_identity()
        data = request.get_json()
        
        if not data or not data.get("name"):
            return jsonify({
                "success": False, 
                "error": "Nome da categoria é obrigatório"
            }), 400

        user = User.query.get(current_user_id)
        if not user:
            return jsonify({
                "success": False, 
                "error": "Usuário não encontrado"
            }), 404

        is_template = data.get("is_template", False)

        # Apenas administradores podem criar templates
        if is_template and not user.is_admin:
            return jsonify({
                "success": False,
                "error": "Apenas administradores podem criar categorias de template"
            }), 403

        # ✅ CORRIGIDO: Verifica duplicidade apenas para o usuário específico
        if is_template:
            # Templates: verificar se já existe template com esse nome
            existing = Category.query.filter_by(
                name=data["name"],
                is_template=True
            ).first()
        else:
            # Categorias pessoais: verificar apenas para esse usuário
            existing = Category.query.filter_by(
                name=data["name"],
                user_id=current_user_id,
                is_template=False
            ).first()
        
        if existing:
            if is_template:
                return jsonify({
                    "success": False,
                    "error": "Já existe uma categoria de template com esse nome"
                }), 400
            else:
                return jsonify({
                    "success": False,
                    "error": "Você já tem uma categoria com esse nome"
                }), 400

        category = Category(
            name=data["name"],
            description=data.get("description", ""),
            color=data.get("color", "#3B82F6"),
            user_id=None if is_template else current_user_id,
            is_template=is_template
        )

        db.session.add(category)
        db.session.commit()

        return jsonify({
            "success": True,
            "data": category.to_dict()
        }), 201

    except Exception as e:
        db.session.rollback()
        print(f"❌ Erro em create_category: {str(e)}")
        import traceback
        traceback.print_exc()
        return jsonify({
            "success": False, 
            "error": str(e)
        }), 500


# =====================================================
# ATUALIZAR CATEGORIA
# =====================================================
@category_bp.route("/<int:category_id>", methods=["PUT"])
@jwt_required()
def update_category(category_id):
    try:
        current_user_id = get_jwt_identity()
        user = User.query.get(current_user_id)
        
        if not user:
            return jsonify({
                "success": False, 
                "error": "Usuário não encontrado"
            }), 404

        category = Category.query.get(category_id)
        if not category:
            return jsonify({
                "success": False, 
                "error": "Categoria não encontrada"
            }), 404

        # ✅ CORRIGIDO: Verificar permissões com comparação int
        if category.is_template:
            # Templates só podem ser editados por admin
            if not user.is_admin:
                return jsonify({
                    "success": False,
                    "error": "Apenas administradores podem editar categorias de template"
                }), 403
        else:
            # Categorias pessoais: verifica propriedade
            if category.user_id is not None:
                if int(category.user_id) != int(current_user_id) and not user.is_admin:
                    return jsonify({
                        "success": False,
                        "error": "Você só pode editar suas próprias categorias"
                    }), 403

        data = request.get_json()
        if not data:
            return jsonify({
                "success": False, 
                "error": "Dados não fornecidos"
            }), 400

        # Atualiza campos
        if "name" in data:
            # Verifica duplicidade do novo nome
            existing = Category.query.filter(
                Category.name == data["name"],
                Category.id != category_id,
                Category.is_template == category.is_template,
                Category.user_id == (None if category.is_template else current_user_id)
            ).first()
            
            if existing:
                return jsonify({
                    "success": False,
                    "error": "Já existe uma categoria com esse nome"
                }), 400
            
            category.name = data["name"]
            
        if "description" in data:
            category.description = data["description"]
        if "color" in data:
            category.color = data["color"]

        db.session.commit()

        return jsonify({
            "success": True,
            "data": category.to_dict()
        }), 200

    except Exception as e:
        db.session.rollback()
        print(f"❌ Erro em update_category: {str(e)}")
        import traceback
        traceback.print_exc()
        return jsonify({
            "success": False, 
            "error": str(e)
        }), 500


# =====================================================
# DELETAR CATEGORIA
# =====================================================
@category_bp.route("/<int:category_id>", methods=["DELETE"])
@jwt_required()
def delete_category(category_id):
    try:
        current_user_id = get_jwt_identity()
        
        print(f"🗑️ DELETE CATEGORY - ID: {category_id}")
        print(f"   User ID: {current_user_id} (tipo: {type(current_user_id)})")
        
        user = User.query.get(current_user_id)
        if not user:
            print(f"   ❌ Usuário não encontrado")
            return jsonify({
                "success": False, 
                "error": "Usuário não encontrado"
            }), 404

        category = Category.query.get(category_id)
        if not category:
            print(f"   ❌ Categoria não encontrada")
            return jsonify({
                "success": False, 
                "error": "Categoria não encontrada"
            }), 404

        print(f"   Categoria: {category.name}")
        print(f"   Category User ID: {category.user_id} (tipo: {type(category.user_id)})")
        print(f"   Is Template: {category.is_template}")
        print(f"   User is Admin: {user.is_admin}")

        # ✅ CORRIGIDO: Validação de permissões com comparação int
        if category.is_template:
            # Templates só podem ser deletados por admin
            if not user.is_admin:
                print(f"   ❌ Negado: Template sem ser admin")
                return jsonify({
                    "success": False,
                    "error": "Apenas administradores podem deletar categorias de template"
                }), 403
        else:
            # Categorias pessoais: verifica propriedade
            if category.user_id is None:
                print(f"   ❌ Categoria sem dono (dados corrompidos)")
                return jsonify({
                    "success": False,
                    "error": "Esta categoria está inválida. Contate o suporte."
                }), 400
            
            # ✅ Comparação segura int com int
            if int(category.user_id) != int(current_user_id):
                if not user.is_admin:
                    print(f"   ❌ Negado: Não é dono ({category.user_id} != {current_user_id})")
                    return jsonify({
                        "success": False,
                        "error": "Você só pode deletar suas próprias categorias"
                    }), 403
                else:
                    print(f"   ✅ Permitido: Admin deletando categoria de outro usuário")
            else:
                print(f"   ✅ Permitido: Dono deletando sua categoria")

        # Verifica se há prompts associados
        if len(category.prompts) > 0:
            print(f"   ❌ Categoria tem {len(category.prompts)} prompts associados")
            return jsonify({
                "success": False,
                "error": f"Não é possível deletar esta categoria pois ela possui {len(category.prompts)} prompt(s) associado(s)"
            }), 400

        db.session.delete(category)
        db.session.commit()
        
        print(f"   ✅ Categoria deletada com sucesso")

        return jsonify({
            "success": True,
            "message": "Categoria deletada com sucesso"
        }), 200

    except Exception as e:
        db.session.rollback()
        print(f"   ❌ Erro em delete_category: {str(e)}")
        import traceback
        traceback.print_exc()
        return jsonify({
            "success": False, 
            "error": str(e)
        }), 500