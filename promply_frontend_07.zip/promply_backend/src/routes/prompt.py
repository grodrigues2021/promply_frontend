from flask import Blueprint, request, jsonify
from src.extensions import db
from src.models.prompt import Prompt, Category
from src.models.user import User
from flask_jwt_extended import jwt_required, get_jwt_identity
from sqlalchemy import or_
import re

prompt_bp = Blueprint("prompt", __name__)

# =====================================
# 🆕 VALIDAÇÃO DE URL DE IMAGEM
# =====================================
def validate_image_url(url):
    """
    Valida se a URL da imagem é segura e válida
    
    Aceita:
    - URLs do Unsplash
    - URLs do Imgur
    - URLs do Cloudinary
    - Data URIs (base64)
    - Outras URLs HTTPS válidas
    """
    if not url:
        return True  # URL vazia é válida (opcional)
    
    # Remove espaços em branco
    url = url.strip()
    
    if not url:
        return True
    
    # Permite data URIs (imagens base64)
    if url.startswith('data:image/'):
        return True
    
    # Padrão de URL válida
    url_pattern = re.compile(
        r'^https?://'  # http:// ou https://
        r'(?:(?:[A-Z0-9](?:[A-Z0-9-]{0,61}[A-Z0-9])?\.)+[A-Z]{2,6}\.?|'  # domínio
        r'localhost|'  # localhost
        r'\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3})'  # ou IP
        r'(?::\d+)?'  # porta opcional
        r'(?:/?|[/?]\S+)$', re.IGNORECASE)
    
    return bool(url_pattern.match(url))


@prompt_bp.route("/", methods=["GET"])
@jwt_required()
def get_prompts():
    """Retorna todos os prompts do usuário com filtros opcionais"""
    try:
        current_user_id = get_jwt_identity()
        
        category_id = request.args.get("category_id", type=int)
        search = request.args.get("search", "")
        favorites_only = request.args.get("favorites_only", "false").lower() == "true"
        sort_by = request.args.get("sort_by", "created_at")
        sort_order = request.args.get("sort_order", "desc")
        
        user = User.query.get(current_user_id)
        if not user:
            return jsonify({"success": False, "error": "Usuário não encontrado"}), 404

        # ✅ CORRIGIDO: TODOS os usuários veem apenas seus próprios prompts
        query = Prompt.query.filter(Prompt.user_id == current_user_id)

        if category_id:
            query = query.filter(Prompt.category_id == category_id)
        
        if search:
            search_term = f"%{search}%"
            query = query.filter(
                or_(
                    Prompt.title.ilike(search_term),
                    Prompt.content.ilike(search_term),
                    Prompt.description.ilike(search_term),
                    Prompt.tags.ilike(search_term)
                )
            )
        
        if favorites_only:
            query = query.filter(Prompt.is_favorite == True)
        
        if sort_by == "title":
            order_column = Prompt.title
        elif sort_by == "updated_at":
            order_column = Prompt.updated_at
        elif sort_by == "usage_count":
            order_column = Prompt.usage_count
        else:
            order_column = Prompt.created_at
        
        if sort_order == "asc":
            query = query.order_by(order_column.asc())
        else:
            query = query.order_by(order_column.desc())
        
        prompts = query.all()
        
        return jsonify({
            "success": True,
            "data": [prompt.to_dict() for prompt in prompts],
            "total": len(prompts)
        })
        
    except Exception as e:
        print(f"❌ Erro em get_prompts: {str(e)}")
        import traceback
        traceback.print_exc()
        return jsonify({
            "success": False,
            "error": str(e)
        }), 500


@prompt_bp.route("/", methods=["POST"])
@jwt_required()
def create_prompt():
    """Cria um novo prompt"""
    try:
        current_user_id = get_jwt_identity()
        data = request.get_json()
        
        if not data or not data.get("title") or not data.get("content"):
            return jsonify({
                "success": False,
                "error": "Título e conteúdo são obrigatórios"
            }), 400
        
        # 🆕 Validar URL da imagem se fornecida
        image_url = data.get("image_url", "").strip() if data.get("image_url") else None
        if image_url and not validate_image_url(image_url):
            return jsonify({
                "success": False,
                "error": "URL de imagem inválida. Use URLs HTTPS válidas ou data URIs."
            }), 400
        
        # 🆕 Processar video_url (YouTube)
        video_url = data.get("video_url", "").strip() if data.get("video_url") else None

        category_id = data.get("category_id")
        
        # ✅ CORRIGIDO: Tratar 'none' como None
        if category_id == 'none' or category_id == '' or category_id is None:
            category_id = None
        else:
            # Converter para int se for string numérica
            try:
                category_id = int(category_id)
            except (ValueError, TypeError):
                category_id = None
        
        # ✅ Validar categoria APENAS se fornecida
        if category_id is not None:
            category = Category.query.get(category_id)
            
            if not category:
                return jsonify({
                    "success": False,
                    "error": "Categoria não encontrada"
                }), 404
            
            user = User.query.get(current_user_id)
            if not user:
                return jsonify({"success": False, "error": "Usuário não encontrado"}), 404

            # ✅ CORRIGIDO: Validar permissões considerando user_id None
            if category.is_template:
                if not user.is_admin:
                    return jsonify({
                        "success": False, 
                        "error": "Apenas administradores podem adicionar prompts a categorias de template"
                    }), 403
            else:
                if category.user_id is None:
                    return jsonify({
                        "success": False,
                        "error": "Esta categoria está inválida. Contate o suporte."
                    }), 400
                
                if int(category.user_id) != int(current_user_id) and not user.is_admin:
                    return jsonify({
                        "success": False,
                        "error": "Você só pode adicionar prompts às suas próprias categorias"
                    }), 403
        
        # ✅ Processar tags
        tags = data.get("tags", [])
        if isinstance(tags, list):
            tags_str = ",".join(str(tag).strip() for tag in tags if tag)
        else:
            tags_str = str(tags) if tags else ""
        
        prompt = Prompt(
            title=data["title"],
            content=data["content"],
            description=data.get("description", ""),
            tags=tags_str,
            image_url=image_url,  # 🆕 Adicionar URL da imagem
            video_url = data.get("video_url", "").strip() if data.get("video_url") else None,
            category_id=category_id,
            is_favorite=data.get("is_favorite", False),
            user_id=current_user_id
        )

        db.session.add(prompt)
        db.session.commit()
        
        return jsonify({
            "success": True,
            "message": "Prompt criado com sucesso!",
            "data": prompt.to_dict()
        }), 201
        
    except Exception as e:
        db.session.rollback()
        print(f"❌ Erro em create_prompt: {str(e)}")
        import traceback
        traceback.print_exc()
        return jsonify({
            "success": False,
            "error": str(e)
        }), 500


@prompt_bp.route("/<int:prompt_id>", methods=["GET"])
@jwt_required()
def get_prompt(prompt_id):
    """Retorna um prompt específico"""
    try:
        current_user_id = get_jwt_identity()
        user = User.query.get(current_user_id)
        
        if not user:
            return jsonify({"success": False, "error": "Usuário não encontrado"}), 404

        prompt = Prompt.query.filter_by(
            id=prompt_id, 
            user_id=current_user_id
        ).first_or_404()
        
        return jsonify({
            "success": True,
            "data": prompt.to_dict()
        })
        
    except Exception as e:
        print(f"❌ Erro em get_prompt: {str(e)}")
        return jsonify({
            "success": False,
            "error": str(e)
        }), 500


@prompt_bp.route("/<int:prompt_id>", methods=["PUT"])
@jwt_required()
def update_prompt(prompt_id):
    """Atualiza um prompt"""
    try:
        current_user_id = get_jwt_identity()

        try:
            current_user_id = int(current_user_id)
        except (TypeError, ValueError):
            return jsonify({"success": False, "error": "Token de autenticação inválido"}), 401
        
        user = User.query.get(current_user_id)
        
        if not user:
            return jsonify({"success": False, "error": "Usuário não encontrado"}), 404

        prompt = Prompt.query.filter_by(
            id=prompt_id, 
            user_id=current_user_id
        ).first_or_404()

        data = request.get_json()
        
        if not data:
            return jsonify({
                "success": False,
                "error": "Dados não fornecidos"
            }), 400
        
        # 🆕 Atualizar URL da imagem se fornecida
        if "image_url" in data:
            image_url = data["image_url"].strip() if data["image_url"] else None
            
            # Validar URL se não for None ou vazia
            if image_url and not validate_image_url(image_url):
                return jsonify({
                    "success": False,
                    "error": "URL de imagem inválida. Use URLs HTTPS válidas ou data URIs."
                }), 400
            
            prompt.image_url = image_url

        if "video_url" in data:
            prompt.video_url = data["video_url"].strip() if data["video_url"] else None    
        
        # ✅ Validar nova categoria
        if "category_id" in data:
            category_id = data["category_id"]
            
            if category_id and category_id != 'none':
                new_category = Category.query.get(category_id)
                if not new_category:
                    return jsonify({
                        "success": False,
                        "error": "Nova categoria não encontrada"
                    }), 400
                
                if new_category.is_template and not user.is_admin:
                    return jsonify({
                        "success": False, 
                        "error": "Apenas administradores podem associar prompts a categorias de template"
                    }), 403
                
                if not new_category.is_template and new_category.user_id != current_user_id and not user.is_admin:
                    return jsonify({
                        "success": False, 
                        "error": "Você só pode associar prompts às suas próprias categorias"
                    }), 403
                
                prompt.category_id = category_id
            else:
                prompt.category_id = None
        
        if "title" in data:
            prompt.title = data["title"]
        if "content" in data:
            prompt.content = data["content"]
        if "description" in data:
            prompt.description = data["description"]
        if "tags" in data:
            tags = data["tags"]
            if isinstance(tags, list):
                prompt.tags = ",".join(str(tag).strip() for tag in tags if tag)
            else:
                prompt.tags = str(tags) if tags else ""
        if "is_favorite" in data:
            prompt.is_favorite = data["is_favorite"]
        
        db.session.commit()
        
        return jsonify({
            "success": True,
            "message": "Prompt atualizado com sucesso!",
            "data": prompt.to_dict()
        })
        
    except Exception as e:
        db.session.rollback()
        print(f"❌ Erro em update_prompt: {str(e)}")
        import traceback
        traceback.print_exc()
        return jsonify({
            "success": False,
            "error": str(e)
        }), 500


@prompt_bp.route("/<int:prompt_id>", methods=["DELETE"])
@jwt_required()
def delete_prompt(prompt_id):
    """Deleta um prompt"""
    try:
        current_user_id = get_jwt_identity()
        user = User.query.get(current_user_id)
        
        if not user:
            return jsonify({"success": False, "error": "Usuário não encontrado"}), 404

        prompt = Prompt.query.filter_by(
            id=prompt_id, 
            user_id=current_user_id
        ).first_or_404()

        db.session.delete(prompt)
        db.session.commit()
        
        return jsonify({
            "success": True,
            "message": "Prompt deletado com sucesso"
        })
        
    except Exception as e:
        db.session.rollback()
        print(f"❌ Erro em delete_prompt: {str(e)}")
        return jsonify({
            "success": False,
            "error": str(e)
        }), 500


@prompt_bp.route("/<int:prompt_id>/copy", methods=["POST"])
@jwt_required()
def copy_prompt(prompt_id):
    """Incrementa o contador de uso quando um prompt é copiado"""
    try:
        current_user_id = get_jwt_identity()
        user = User.query.get(current_user_id)
        
        if not user:
            return jsonify({"success": False, "error": "Usuário não encontrado"}), 404

        prompt = Prompt.query.filter_by(
            id=prompt_id, 
            user_id=current_user_id
        ).first_or_404()
        
        # Incrementar contador de uso
        prompt.usage_count += 1
        db.session.commit()
        
        return jsonify({
            "success": True,
            "message": "Contador de uso atualizado",
            "usage_count": prompt.usage_count
        })
        
    except Exception as e:
        db.session.rollback()
        print(f"❌ Erro em copy_prompt: {str(e)}")
        return jsonify({
            "success": False,
            "error": str(e)
        }), 500


@prompt_bp.route("/<int:prompt_id>/favorite", methods=["POST"])
@jwt_required()
def toggle_favorite(prompt_id):
    """Alterna o status de favorito de um prompt"""
    try:
        current_user_id = get_jwt_identity()
        user = User.query.get(current_user_id)
        
        if not user:
            return jsonify({"success": False, "error": "Usuário não encontrado"}), 404

        prompt = Prompt.query.filter_by(
            id=prompt_id, 
            user_id=current_user_id
        ).first_or_404()
        
        prompt.is_favorite = not prompt.is_favorite
        db.session.commit()
        
        return jsonify({
            "success": True,
            "message": "Status de favorito atualizado!",
            "data": prompt.to_dict()
        })
        
    except Exception as e:
        db.session.rollback()
        print(f"❌ Erro em toggle_favorite: {str(e)}")
        return jsonify({
            "success": False,
            "error": str(e)
        }), 500


@prompt_bp.route("/stats", methods=["GET"])
@jwt_required()
def get_stats():
    """Retorna estatísticas gerais"""
    try:
        current_user_id = get_jwt_identity()
        
        total_prompts = Prompt.query.filter_by(user_id=current_user_id).count()
        total_categories = Category.query.filter_by(user_id=current_user_id).count()
        favorite_prompts = Prompt.query.filter_by(user_id=current_user_id, is_favorite=True).count()
        most_used_prompt = Prompt.query.filter_by(user_id=current_user_id).order_by(Prompt.usage_count.desc()).first()
        
        return jsonify({
            "success": True,
            "data": {
                "total_prompts": total_prompts,
                "total_categories": total_categories,
                "favorite_prompts": favorite_prompts,
                "most_used_prompt": most_used_prompt.to_dict() if most_used_prompt else None
            }
        })
        
    except Exception as e:
        print(f"❌ Erro em get_stats: {str(e)}")
        return jsonify({
            "success": False,
            "error": str(e)
        }), 500