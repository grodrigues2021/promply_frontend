from flask import Blueprint, request, jsonify
import os
from src.utils.b2_client import upload_file_to_b2

upload_bp = Blueprint("upload", __name__)

@upload_bp.route("/upload", methods=["POST"])
def upload_file():
    """Recebe um arquivo e faz upload para o Backblaze B2"""
    try:
        if "file" not in request.files:
            return jsonify({"success": False, "error": "Nenhum arquivo enviado"}), 400

        file = request.files["file"]

        temp_path = f"/tmp/{file.filename}"
        file.save(temp_path)

        object_name = f"uploads/{file.filename}"
        url = upload_file_to_b2(temp_path, object_name)

        os.remove(temp_path)

        return jsonify({"success": True, "url": url})

    except Exception as e:
        print(f"❌ Erro no upload: {str(e)}")
        return jsonify({"success": False, "error": str(e)}), 500
