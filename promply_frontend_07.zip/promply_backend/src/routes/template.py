from flask import Blueprint, request, jsonify
from flask_jwt_extended import jwt_required, get_jwt_identity
from src.extensions import db
from src.models.prompt import Template, Category, Prompt
from src.models.user import User
from functools import wraps
from datetime import datetime

template_bp = Blueprint("template", __name__)

# Decorator para verificar se usuário é admin
def admin_required(fn):
    @wraps(fn)
    @jwt_required()
    def wrapper(*args, **kwargs):
        current_user_id = int(get_jwt_identity())
        user = User.query.get(current_user_id)
        
        if not user or not user.is_admin:
            return jsonify({
                "success": False,
                "error": "Acesso negado. Apenas administradores."
            }), 403
        
        return fn(*args, **kwargs)
    return wrapper


# =========================
# Listar todos os templates ativos
# GET /api/templates
# =========================
@template_bp.route("/", methods=["GET"], strict_slashes=False)
def list_templates():
    """Lista todos os templates ativos"""
    try:
        templates = Template.query.filter_by(is_active=True).order_by(Template.created_at.desc()).all()
        
        return jsonify({
            "success": True,
            "data": [template.to_dict() for template in templates],
            "total": len(templates)
        }), 200
        
    except Exception as e:
        print(f"❌ Erro ao listar templates: {str(e)}")
        return jsonify({
            "success": False,
            "error": str(e)
        }), 500


# =========================
# Buscar template específico
# GET /api/templates/<id>
# =========================
@template_bp.route("/<int:template_id>", methods=["GET"])
def get_template(template_id):
    """Retorna um template específico"""
    try:
        template = Template.query.get(template_id)
        
        if not template or not template.is_active:
            return jsonify({
                "success": False,
                "error": "Template não encontrado"
            }), 404
        
        return jsonify({
            "success": True,
            "data": template.to_dict()
        }), 200
        
    except Exception as e:
        return jsonify({
            "success": False,
            "error": str(e)
        }), 500


# =========================
# Usar template (criar prompt)
# POST /api/templates/<id>/use
# =========================
@template_bp.route("/<int:template_id>/use", methods=["POST"])
@jwt_required()
def use_template(template_id):
    """Cria um novo prompt baseado em um template"""
    try:
        current_user_id = int(get_jwt_identity())
        template = Template.query.get(template_id)
        
        if not template or not template.is_active:
            return jsonify({
                "success": False,
                "error": "Template não encontrado"
            }), 404
        
        data = request.get_json(silent=True) or {}
        
        # Cria novo prompt baseado no template
        new_prompt = Prompt(
            user_id=current_user_id,
            title=data.get('title', template.title),
            content=data.get('content', template.content),
            description=data.get('description', template.description),
            tags=data.get('tags', template.tags),
            category_id=data.get('category_id', template.category_id),
            image_url=template.image_url,
            video_url=template.video_url,  # ✅ copia o link do vídeo
            is_favorite=data.get('is_favorite', False)
        )
        
        # Incrementa contador de uso do template
        template.increment_usage()
        
        db.session.add(new_prompt)
        db.session.commit()
        
        return jsonify({
            "success": True,
            "message": "Prompt criado com sucesso a partir do template!",
            "data": new_prompt.to_dict()
        }), 201
        
    except Exception as e:
        db.session.rollback()
        print(f"❌ Erro ao usar template: {str(e)}")
        return jsonify({
            "success": False,
            "error": str(e)
        }), 500


# =========================
# Criar template (ADMIN ONLY)
# POST /api/templates
# =========================
@template_bp.route("/", methods=["POST"])
@jwt_required()
def create_template():
    try:
        current_user_id = get_jwt_identity()
        user = User.query.get(current_user_id)
        
        if not user or not user.is_admin:
            return jsonify({
                "success": False,
                "error": "Apenas administradores podem criar templates"
            }), 403
        
        data = request.get_json()

        # Validações básicas
        if not data.get('title'):
            return jsonify({"success": False, "error": "Título é obrigatório"}), 400

        if not data.get('content'):
            return jsonify({"success": False, "error": "Conteúdo é obrigatório"}), 400

        # Validação opcional de imagem
        image_url = data.get('image_url')
        if image_url:
            if not image_url.startswith('data:image/'):
                return jsonify({"success": False, "error": "Formato de imagem inválido"}), 400
            if len(image_url) > 7000000:
                return jsonify({"success": False, "error": "Imagem muito grande (máx. 5MB)"}), 400

        # Converter tags
        tags = data.get('tags', [])
        if isinstance(tags, list):
            tags = ','.join(tags)

        category_id = data.get('category_id')
        if category_id == 'none':
            category_id = None

        # Criação do template
        template = Template(
            title=data['title'],
            description=data.get('description', ''),
            content=data['content'],
            category_id=category_id,
            tags=tags,
            image_url=image_url,
            video_url=data.get('video_url'),  # ✅ NOVO CAMPO
            created_by=current_user_id,
            is_active=True
        )

        db.session.add(template)
        db.session.commit()

        return jsonify({
            "success": True,
            "data": template.to_dict()
        }), 201

    except Exception as e:
        db.session.rollback()
        print(f"❌ Erro ao criar template: {str(e)}")
        import traceback
        traceback.print_exc()
        return jsonify({
            "success": False,
            "error": str(e)
        }), 500


# =========================
# Atualizar template (ADMIN ONLY)
# PUT /api/templates/<id>
# =========================
@template_bp.route("/<int:template_id>", methods=["PUT"])
@jwt_required()
def update_template(template_id):
    try:
        current_user_id = get_jwt_identity()
        user = User.query.get(current_user_id)
        
        if not user or not user.is_admin:
            return jsonify({
                "success": False,
                "error": "Apenas administradores podem editar templates"
            }), 403
        
        template = Template.query.get(template_id)
        if not template:
            return jsonify({
                "success": False,
                "error": "Template não encontrado"
            }), 404
        
        data = request.get_json()
        
        # Atualizar campos
        if 'title' in data:
            template.title = data['title']
        if 'description' in data:
            template.description = data['description']
        if 'content' in data:
            template.content = data['content']
        if 'category_id' in data:
            category_id = data['category_id']
            if category_id == 'none':
                category_id = None
            template.category_id = category_id
        
        # Converter tags se for array
        if 'tags' in data:
            tags = data['tags']
            if isinstance(tags, list):
                tags = ','.join(tags)
            template.tags = tags
        
        # Atualizar imagem
        if 'image_url' in data:
            image_url = data['image_url']
            
            if image_url:
                if not image_url.startswith('data:image/'):
                    return jsonify({
                        "success": False,
                        "error": "Formato de imagem inválido"
                    }), 400
                
                if len(image_url) > 7000000:
                    return jsonify({
                        "success": False,
                        "error": "Imagem muito grande"
                    }), 400
            
            template.image_url = image_url

        if 'video_url' in data:
                
            template.video_url = data['video_url']

        
        template.updated_at = datetime.utcnow()
        db.session.commit()
        
        return jsonify({
            "success": True,
            "data": template.to_dict()
        }), 200
        
    except Exception as e:
        db.session.rollback()
        print(f"❌ Erro ao atualizar template: {str(e)}")
        import traceback
        traceback.print_exc()
        return jsonify({
            "success": False,
            "error": str(e)
        }), 500


# =========================
# Deletar template (ADMIN ONLY)
# DELETE /api/templates/<id>
# =========================
@template_bp.route("/<int:template_id>", methods=["DELETE"])
@admin_required
def delete_template(template_id):
    """Soft delete de um template"""
    try:
        template = Template.query.get(template_id)
        
        if not template:
            return jsonify({
                "success": False,
                "error": "Template não encontrado"
            }), 404
        
        # Soft delete
        template.is_active = False
        db.session.commit()
        
        return jsonify({
            "success": True,
            "message": "Template deletado com sucesso"
        }), 200
        
    except Exception as e:
        db.session.rollback()
        print(f"❌ Erro ao deletar template: {str(e)}")
        return jsonify({
            "success": False,
            "error": str(e)
        }), 500