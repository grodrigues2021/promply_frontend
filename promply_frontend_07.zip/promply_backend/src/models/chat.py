"""
Modelos de dados para o sistema de chat interno
Arquivo: prompt_manager/src/models/chat.py
"""

from datetime import datetime
from src.extensions import db


class ChatPost(db.Model):
    """Modelo para posts do chat interno"""
    __tablename__ = 'chat_posts'
    
    id = db.Column(db.Integer, primary_key=True)
    author_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)
    content = db.Column(db.Text, nullable=False)
    shared_prompt_id = db.Column(db.Integer, db.ForeignKey('prompt.id'), nullable=True)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    # Relacionamentos
    author = db.relationship('User', backref='chat_posts', lazy=True)
    shared_prompt = db.relationship('Prompt', backref='shared_in_chat', lazy=True)
    comments = db.relationship('ChatComment', backref='post', lazy='dynamic', cascade='all, delete-orphan')
    likes = db.relationship('ChatLike', backref='post', lazy='dynamic', cascade='all, delete-orphan')
    
    def to_dict(self, current_user_id=None):
        """Serializa o post com contadores e status de like do usuário atual"""
        likes_count = self.likes.count()
        comments_count = self.comments.count()
        user_liked = False
        
        if current_user_id:
            user_liked = self.likes.filter_by(user_id=current_user_id).first() is not None
        
        result = {
            'id': self.id,
            'content': self.content,
            'author': {
                'id': self.author.id,
                'name': self.author.name,
                'email': self.author.email
            },
            'likes_count': likes_count,
            'comments_count': comments_count,
            'user_liked': user_liked,
            'created_at': self.created_at.isoformat(),
            'updated_at': self.updated_at.isoformat(),
            'is_shared_prompt': self.shared_prompt_id is not None
        }
        
        # ✅ ATUALIZADO: Se for um prompt compartilhado, incluir TODOS os dados
        if self.shared_prompt_id and self.shared_prompt:
            # Buscar autor do prompt via query direta
            from src.models.user import User
            prompt_author = User.query.get(self.shared_prompt.user_id)
            
            result['shared_prompt'] = {
                'id': self.shared_prompt.id,
                'title': self.shared_prompt.title,
                'content': self.shared_prompt.content,
                'description': self.shared_prompt.description or '',
                'tags': self.shared_prompt.tags or '',
                'category_id': self.shared_prompt.category_id,
                'is_favorite': self.shared_prompt.is_favorite,
                'author': {
                    'id': self.shared_prompt.user_id,
                    'name': prompt_author.name if prompt_author else 'Desconhecido'
                }
            }
        
        return result


class ChatComment(db.Model):
    """Modelo para comentários em posts"""
    __tablename__ = 'chat_comments'
    
    id = db.Column(db.Integer, primary_key=True)
    post_id = db.Column(db.Integer, db.ForeignKey('chat_posts.id'), nullable=False)
    author_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)
    content = db.Column(db.Text, nullable=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    
    # Relacionamentos
    author = db.relationship('User', backref='chat_comments', lazy=True)
    
    def to_dict(self):
        """Serializa o comentário"""
        return {
            'id': self.id,
            'post_id': self.post_id,
            'content': self.content,
            'author': {
                'id': self.author.id,
                'name': self.author.name,
                'email': self.author.email
            },
            'created_at': self.created_at.isoformat()
        }


class ChatLike(db.Model):
    """Modelo para curtidas em posts"""
    __tablename__ = 'chat_likes'
    
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)
    post_id = db.Column(db.Integer, db.ForeignKey('chat_posts.id'), nullable=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    
    # Constraint único para evitar múltiplas curtidas do mesmo usuário
    __table_args__ = (
        db.UniqueConstraint('user_id', 'post_id', name='unique_user_post_like'),
    )
    
    # Relacionamentos
    user = db.relationship('User', backref='chat_likes', lazy=True)
