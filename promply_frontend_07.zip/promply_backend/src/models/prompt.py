# ==========================================
# src/models/prompt.py
# ==========================================
from flask_sqlalchemy import SQLAlchemy
from datetime import datetime
from src.models.user import db

class Category(db.Model):
    __tablename__ = "category"
    
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(100), nullable=False)
    description = db.Column(db.Text, nullable=True)
    color = db.Column(db.String(7), default='#3B82F6')
    user_id = db.Column(db.Integer, db.ForeignKey("user.id"), nullable=True)  # ✅ ADICIONADO
    is_template = db.Column(db.Boolean, default=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    
    # ✅ Constraint único por usuário e nome
    __table_args__ = (
        db.UniqueConstraint('user_id', 'name', name='uq_user_category_name'),
    )
    
    # ✅ Relationships
    prompts = db.relationship('Prompt', backref='category', lazy=True, cascade='all, delete-orphan')

    def __repr__(self):
        return f"<Category {self.name}>"

    def to_dict(self):
        return {
            "id": self.id,
            "name": self.name,
            "description": self.description,
            "color": self.color,
            "is_template": self.is_template,
            "prompt_count": len(self.prompts),
            "created_at": self.created_at.isoformat() if self.created_at else None
        }


class Prompt(db.Model):
    __tablename__ = "prompt"
    
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey("user.id"), nullable=False)
    title = db.Column(db.String(200), nullable=False)
    content = db.Column(db.Text, nullable=False)
    description = db.Column(db.Text, nullable=True)
    tags = db.Column(db.String(500), nullable=True)
    category_id = db.Column(db.Integer, db.ForeignKey('category.id'), nullable=True)
    is_favorite = db.Column(db.Boolean, default=False)
    usage_count = db.Column(db.Integer, default=0)
    image_url = db.Column(db.Text, nullable=True)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    video_url = db.Column(db.String(255), nullable=True)


    def __repr__(self):
        return f'<Prompt {self.title}>'

    def to_dict(self):
        return {
            'id': self.id,
            'title': self.title,
            'content': self.content,
            'description': self.description,
            'tags': self.tags.split(',') if self.tags else [],
            'user_id': self.user_id,
            'category_id': self.category_id,
            'category': {
                'id': self.category.id,
                'name': self.category.name,
                'color': self.category.color
            } if self.category else None,
            'is_favorite': self.is_favorite,
            'usage_count': self.usage_count,
            'image_url': self.image_url,
            'created_at': self.created_at.isoformat() if self.created_at else None,
            'updated_at': self.updated_at.isoformat() if self.updated_at else None,
            "video_url": self.video_url,

        }

    def increment_usage(self):
        self.usage_count += 1
        db.session.commit()


class Template(db.Model):
    __tablename__ = "template"
    
    id = db.Column(db.Integer, primary_key=True)
    title = db.Column(db.String(200), nullable=False)
    content = db.Column(db.Text, nullable=False)
    description = db.Column(db.Text, nullable=True)
    tags = db.Column(db.String(500), nullable=True)
    category_id = db.Column(db.Integer, db.ForeignKey('category.id'), nullable=True)
    usage_count = db.Column(db.Integer, default=0)
    created_by = db.Column(db.Integer, db.ForeignKey("user.id"), nullable=False)
    is_active = db.Column(db.Boolean, default=True)
    image_url = db.Column(db.Text, nullable=True)  # ✅ ADICIONADO
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    video_url = db.Column(db.String(255), nullable=True)  # ✅ NOVO CAMPO


    # Relationships
    category = db.relationship('Category', backref='templates', lazy=True)
    creator = db.relationship('User', backref='templates_created', lazy=True)

    def __repr__(self):
        return f'<Template {self.title}>'

    def to_dict(self):
        return {
            'id': self.id,
            'title': self.title,
            'content': self.content,
            'description': self.description,
            'tags': self.tags.split(',') if self.tags else [],
            'category_id': self.category_id,
            'category_name': self.category.name if self.category else None,
            'usage_count': self.usage_count,
            'is_active': self.is_active,
            'image_url': self.image_url,  # ✅ ADICIONADO
            "video_url": self.video_url,
            'created_by': self.created_by,
            'creator_name': self.creator.name if self.creator else None,
            'created_at': self.created_at.isoformat() if self.created_at else None,
            'updated_at': self.updated_at.isoformat() if self.updated_at else None
        }

    def increment_usage(self):
        self.usage_count += 1
        db.session.commit()