from dotenv import load_dotenv
import os

# Carrega .env
# 🔧 Detecta ambiente automaticamente
env_name = os.getenv("FLASK_ENV")

if not env_name:
    # Se não estiver definido no sistema, assume development localmente
    env_name = "development"
    os.environ["FLASK_ENV"] = env_name


if env_name == "staging":
    dotenv_file = ".env.staging"
elif env_name == "production":
    dotenv_file = ".env.production"
else:
    dotenv_file = ".env.development"

dotenv_path = os.path.join(os.path.dirname(__file__), "..", dotenv_file)

if os.path.exists(dotenv_path):
    load_dotenv(dotenv_path)
    print(f"🌍 Ambiente carregado de arquivo: {env_name} -> {dotenv_file}")
else:
    print(f"🌍 Ambiente: {env_name} (usando variáveis de ambiente do sistema)")

import sys
from flask_mail import Mail
from flask_migrate import Migrate
from datetime import timedelta

sys.path.insert(0, os.path.dirname(os.path.dirname(__file__)))

from flask import Flask, request, jsonify
from flask_cors import CORS
from werkzeug.middleware.proxy_fix import ProxyFix
from src.routes.upload_route import upload_bp

from src.extensions import db, jwt, oauth
from src.models.prompt import Template, Category, Prompt
from src.routes.auth import auth_bp
from src.routes.category import category_bp
from src.routes.prompt import prompt_bp
from src.routes.template import template_bp
from src.routes.chat import chat_bp
from flask_jwt_extended import (
    JWTManager,
    get_jwt_identity,
    create_access_token,
    set_access_cookies,
    jwt_required,
    unset_jwt_cookies
)

# Logging global
import logging
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(message)s",
)

# Cria app
app = Flask(__name__)
app.url_map.strict_slashes = False  # ✅ Desabilita strict slashes
# ✅ CRÍTICO: ProxyFix DEVE vir antes de qualquer outra configuração
app.wsgi_app = ProxyFix(
    app.wsgi_app, 
    x_for=1,      # Trust X-Forwarded-For
    x_proto=1,    # Trust X-Forwarded-Proto
    x_host=1,     # Trust X-Forwarded-Host
    x_port=1,     # Trust X-Forwarded-Port
    x_prefix=1    # Trust X-Forwarded-Prefix
)

# Segredos
app.config["SECRET_KEY"] = os.environ.get("SECRET_KEY", "change-me")
app.config["JWT_SECRET_KEY"] = os.environ.get("JWT_SECRET_KEY", "change-me")

# =====================================
# 🔐 Configurações de Cookies e JWT
# =====================================
app.config["JWT_TOKEN_LOCATION"] = ["cookies"]
app.config["JWT_ACCESS_TOKEN_EXPIRES"] = timedelta(hours=24)

IS_PRODUCTION = env_name in ["staging", "production"]

if IS_PRODUCTION:
    # 🌐 PRODUÇÃO/STAGING (HTTPS no Render)
    app.config["JWT_COOKIE_SECURE"] = True
    app.config["JWT_COOKIE_SAMESITE"] = "None"  # ✅ None para cross-origin
    app.config["JWT_COOKIE_DOMAIN"] = None
    print("✅ Cookies JWT configurados para PRODUÇÃO (HTTPS + SameSite=None)")
else:
    # 💻 DESENVOLVIMENTO LOCAL (HTTP)
    app.config["JWT_COOKIE_SECURE"] = False
    app.config["JWT_COOKIE_SAMESITE"] = "Lax"
    app.config["JWT_COOKIE_DOMAIN"] = None
    print("✅ Cookies JWT configurados para DESENVOLVIMENTO (HTTP + SameSite=Lax)")

app.config["JWT_COOKIE_PATH"] = "/"
app.config["JWT_COOKIE_CSRF_PROTECT"] = False
app.config["JWT_SESSION_COOKIE"] = False

# Google OAuth
app.config["GOOGLE_CLIENT_ID"] = os.environ.get("GOOGLE_CLIENT_ID")
app.config["GOOGLE_CLIENT_SECRET"] = os.environ.get("GOOGLE_CLIENT_SECRET")

if not app.config["GOOGLE_CLIENT_ID"] or not app.config["GOOGLE_CLIENT_SECRET"]:
    print("⚠️ AVISO: GOOGLE_CLIENT_ID/SECRET não configurados - OAuth desabilitado")
else:
    oauth.init_app(app)
    oauth.register(
        name="google",
        server_metadata_url="https://accounts.google.com/.well-known/openid-configuration",
        client_id=app.config["GOOGLE_CLIENT_ID"],
        client_secret=app.config["GOOGLE_CLIENT_SECRET"],
        client_kwargs={"scope": "openid email profile"},
    )
    print("✅ Google OAuth configurado")

# JWT
jwt.init_app(app)

# =====================================
# 🌐 CORS - Configuração CORRETA
# =====================================
ALLOWED_ORIGINS = os.environ.get("CORS_ORIGINS", "").split(",")

if not ALLOWED_ORIGINS or ALLOWED_ORIGINS == [""]:
    ALLOWED_ORIGINS = [
        "https://promply-frontend-staging.onrender.com",
        "https://app-staging.promply.app",
        "https://promply-frontend-prod.onrender.com",
        "https://app.promply.app",
        "http://localhost:5173",
        "http://127.0.0.1:5173",
    ]

ALLOWED_ORIGINS = [origin.strip() for origin in ALLOWED_ORIGINS if origin.strip()]

# ✅ CONFIGURAÇÃO CORRETA DO CORS
CORS(
    app,
    supports_credentials=True,
    origins=ALLOWED_ORIGINS,
    allow_headers=["Content-Type", "Authorization", "Accept", "X-Requested-With"],
    methods=["GET", "POST", "PUT", "DELETE", "OPTIONS", "PATCH"],
    expose_headers=["Set-Cookie", "Access-Control-Allow-Credentials"],
    max_age=3600,  # ✅ Cache preflight por 1 hora
)

print(f"✅ CORS configurado para: {ALLOWED_ORIGINS}")

# ✅ ADICIONAR: Handler específico para OPTIONS (preflight)
@app.before_request
def handle_preflight():
    if request.method == "OPTIONS":
        response = app.make_default_options_response()
        
        origin = request.headers.get('Origin')
        if origin in ALLOWED_ORIGINS:
            response.headers['Access-Control-Allow-Origin'] = origin
            response.headers['Access-Control-Allow-Methods'] = 'GET, POST, PUT, DELETE, OPTIONS, PATCH'
            response.headers['Access-Control-Allow-Headers'] = 'Content-Type, Authorization, Accept, X-Requested-With'
            response.headers['Access-Control-Allow-Credentials'] = 'true'
            response.headers['Access-Control-Max-Age'] = '3600'
        
        return response

# =====================================
# 🗄️ Banco de Dados
# =====================================
def get_database_url():
    """Retorna URL do banco baseado no ambiente"""
    database_url = os.getenv("DATABASE_URL")
    
    if database_url:
        if database_url.startswith("postgres://"):
            database_url = database_url.replace("postgres://", "postgresql://", 1)
        print(f"✅ Usando DATABASE_URL do ambiente: {database_url[:30]}...")
        return database_url
    
    DISK_PATH = os.getenv('DISK_PATH', '/data')
    
    if os.path.exists(DISK_PATH):
        db_path = os.path.join(DISK_PATH, "app.db")
        print(f"✅ Usando SQLite em disco persistente: {DISK_PATH}")
    else:
        from pathlib import Path
        instance_path = os.path.join(os.path.dirname(__file__), 'instance')
        Path(instance_path).mkdir(parents=True, exist_ok=True)
        db_path = os.path.join(instance_path, "app.db")
        print(f"⚠️ Usando SQLite local: {instance_path}")
    
    from pathlib import Path
    Path(os.path.dirname(db_path)).mkdir(parents=True, exist_ok=True)
    
    return f"sqlite:///{db_path}"

app.config["SQLALCHEMY_DATABASE_URI"] = get_database_url()
app.config["SQLALCHEMY_TRACK_MODIFICATIONS"] = False

database_url = app.config["SQLALCHEMY_DATABASE_URI"]

if database_url.startswith("postgresql"):
    app.config["SQLALCHEMY_ENGINE_OPTIONS"] = {
        "pool_size": 10,
        "pool_recycle": 3600,
        "pool_pre_ping": True,
        "connect_args": {
            "connect_timeout": 10,
        }
    }
    print("✅ Configurado para PostgreSQL")
else:
    app.config["SQLALCHEMY_ENGINE_OPTIONS"] = {
        "pool_pre_ping": True,
        "pool_recycle": 300,
        "connect_args": {
            "timeout": 10,
            "check_same_thread": False,
        }
    }
    print("✅ Configurado para SQLite")

db.init_app(app)
migrate = Migrate(app, db)

def init_database():
    """Inicializa banco de dados de forma segura"""
    with app.app_context():
        try:
            print("🔄 Inicializando banco de dados...")
            
            if app.config["SQLALCHEMY_DATABASE_URI"].startswith("sqlite"):
                from sqlalchemy import event
                
                @event.listens_for(db.engine, "connect")
                def set_sqlite_pragma(dbapi_conn, connection_record):
                    cursor = dbapi_conn.cursor()
                    cursor.execute("PRAGMA busy_timeout = 10000")
                    cursor.execute("PRAGMA journal_mode = WAL")
                    cursor.close()
            
            db.create_all()
            
            from src.models.user import User
            admin_user = User.query.filter_by(is_admin=True).first()
            
            if not admin_user:
                print("⚠️ Criando usuário admin padrão...")
                default_admin = User(
                    email="maximizetecnologia@gmail.com",
                    name="Administrador Maximize",
                    is_admin=True,
                    is_verified=True
                )
                default_admin.set_password("Max12Con*@")
                db.session.add(default_admin)
                db.session.commit()
                print("✅ Admin padrão criado")
            
            print("✅ Banco inicializado com sucesso")
            
        except Exception as e:
            print(f"❌ Erro: {str(e)}")
            import traceback
            traceback.print_exc()
            db.session.rollback()
            raise
        finally:
            db.session.remove()

# Flask-Mail
app.config["MAIL_SERVER"] = os.getenv("MAIL_SERVER", "smtppro.zoho.com")
app.config["MAIL_PORT"] = int(os.getenv("MAIL_PORT", 587))
app.config["MAIL_USE_TLS"] = os.getenv("MAIL_USE_TLS", "True") == "True"
app.config["MAIL_USERNAME"] = os.getenv("MAIL_USERNAME")
app.config["MAIL_PASSWORD"] = os.getenv("MAIL_PASSWORD")
app.config["MAIL_DEFAULT_SENDER"] = os.getenv("MAIL_DEFAULT_SENDER")

mail = Mail(app)
print(f"📬 E-mail configurado: {app.config['MAIL_USERNAME']}")

# REGISTRAR BLUEPRINTS DA API
app.register_blueprint(auth_bp, url_prefix="/api/auth")
app.register_blueprint(category_bp, url_prefix="/api/categories")
app.register_blueprint(prompt_bp, url_prefix="/api/prompts")
app.register_blueprint(template_bp, url_prefix="/api/templates")
app.register_blueprint(chat_bp, url_prefix="/api/chat")
app.register_blueprint(upload_bp, url_prefix="/api")

# ============================================
# 📊 ENDPOINT DE ESTATÍSTICAS
# ============================================
@app.route("/api/stats", methods=["GET"])
@jwt_required(optional=True)
def stats():
    try:
        from src.models.prompt import Prompt, Category
        
        current_user_id = get_jwt_identity()
        
        if current_user_id:
            total_prompts = Prompt.query.filter_by(user_id=current_user_id).count()
            total_categories = Category.query.filter_by(
                user_id=current_user_id, 
                is_template=False
            ).count()
            favorite_prompts = Prompt.query.filter_by(
                user_id=current_user_id, 
                is_favorite=True
            ).count()
        else:
            total_prompts = 0
            total_categories = 0
            favorite_prompts = 0

        return jsonify({
            "success": True,
            "data": {
                "total_prompts": total_prompts,
                "total_categories": total_categories,
                "favorite_prompts": favorite_prompts
            }
        }), 200

    except Exception as e:
        print(f"❌ Erro em /api/stats: {str(e)}")
        import traceback
        traceback.print_exc()
        return jsonify({
            "success": False,
            "error": str(e)
        }), 500

# ✅ ROTA RAIZ
@app.route("/")
def index():
    return jsonify({
        "success": True,
        "message": "Prompt Manager API - Promply",
        "version": "2.0",
        "environment": env_name,
        "database": "PostgreSQL" if app.config["SQLALCHEMY_DATABASE_URI"].startswith("postgresql") else "SQLite",
        "endpoints": {
            "auth": "/api/auth",
            "prompts": "/api/prompts",
            "categories": "/api/categories",
            "templates": "/api/templates",
            "chat": "/api/chat",
            "stats": "/api/stats",
            "health": "/health"
        }
    })

# Health Check
@app.route("/health")
def health():
    try:
        db.session.execute(db.text("SELECT 1"))
        db_status = "OK"
    except Exception as e:
        db_status = f"ERROR: {str(e)}"
    
    return jsonify({
        "success": True,
        "status": "healthy",
        "database": db_status,
        "environment": env_name
    })

# Debug Routes
@app.route("/debug/info")
def debug_info():
    try:
        from src.models.user import User
        from src.models.prompt import Category, Prompt
        
        user_count = User.query.count()
        categories_count = Category.query.count()
        prompts_count = Prompt.query.count()
        
        return jsonify({
            "success": True,
            "environment": env_name,
            "database_type": "PostgreSQL" if app.config["SQLALCHEMY_DATABASE_URI"].startswith("postgresql") else "SQLite",
            "database_url": app.config["SQLALCHEMY_DATABASE_URI"][:50] + "...",
            "cors_origins": ALLOWED_ORIGINS,
            "stats": {
                "users": user_count,
                "categories": categories_count,
                "prompts": prompts_count
            }
        })
    except Exception as e:
        return jsonify({
            "success": False,
            "error": str(e)
        }), 500

# Error Handlers
@app.errorhandler(401)
def handle_unauthorized(e):
    return jsonify({
        "success": False,
        "error": "Não autorizado",
        "message": "Token JWT ausente ou inválido"
    }), 401

@app.errorhandler(404)
def not_found(e):
    return jsonify({
        "success": False,
        "error": "Endpoint não encontrado",
        "message": "Verifique a documentação da API"
    }), 404

# CLI Command
@app.cli.command()
def init_db():
    init_database()
    print("✅ Comando init-db concluído")

# Entry Point
if __name__ == "__main__":
    try:
        init_database()
    except Exception as e:
        print(f"⚠️ Aviso: Falha ao inicializar banco: {e}")
    
    port = int(os.environ.get("PORT", 5000))
    app.run(host="0.0.0.0", port=port, debug=(env_name == "development"))